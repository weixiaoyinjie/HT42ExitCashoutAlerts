# HT 42分钟结单预警（独立安装版 v42.1）

从用户上传的 `HTFourPointAlerts_OneUpload.zip` 直接修改，沿用原 WebView 界面、原图像导入与本地 ML Kit OCR、原截图球队/日期/Fixture ID 验证、比赛监控、API-FOOTBALL 接口设置与 OpenAI Key 设置、数据趋势引擎、预警记录与半场结束自动清理。没有改动 `assets/import_parser.js` 和 `ApiClient.java`。

## 本版变化

- 比赛状态实际转为 `1H` 且 API 分钟在 0～2：**开赛**一次提醒。若启动监控晚于2'，不补发虚假的开赛消息。
- 实际比赛 15'：数据复核通知，包括当前比分、xG/射门/射正/禁区/危险进攻（有覆盖才显示）、近期可验证增量、主单与保险单说明。
- 实际比赛 30'：同类数据复核，特别解释 1-0 尚未出现、0-0沉闷等场景。
- 实际比赛 42'：**强提醒打开投注平台逐张人工检查提前结单报价**。**没有代用户自动结单**。缺失统计时仍可用可信 API 比赛状态/比分提醒。
- 比分上涨的进球提醒与已确认红牌提醒：按原有规则保留，直到上半场结束。
- 15～41'：如果主单准确比分已命中同时出现**可验证的近期新攻势**、或 0-0沉闷而主单需要进球、或其他关键比分组合风险变化，可以补充节流推送。去除普通攻势单独推送，默认180秒节流；进球/红牌的独立通知不会因为新风险重复推送。
- Android 通知栏直接说明比分组合、风险证据与AI复核，点击可看更详细数据。AI 结果不阻塞第一时间的基于规则的通知；若后续收到AI，在同一条通知上静默更新，避免再次振动。
- 38～43' 活跃赛事自动把轮询时间压到最多30秒（虽然 API、网络和安卓后台仍可能造成延迟/漏报）。

## 两张/三张准确比分

每场自动识别、加入名单的比赛，在 **已选择比赛** 和 **图片导入中已匹配比赛卡片** 旁均有：

- 方案选择：默认 `两张单`，可改为 `三张单`。
- `主单`，例如 `1-0`。
- `保险单1`，例如 `0-0`。
- 若选择三张，增加 `保险单2`，例如 `2-0`。

输入均按上半场**主队-客队**比分，限制 0-0～9-9，可留空，阻止同一场重复比分。保存到本机应用私有数据，同时同步给后台监控。**保险单只是所持不同比分的标记，不意味着财务保本**；没有真实下注金额、初始赔率及平台结算价，系统不估算组合收益。

## 结单引擎如何解释

按当前比赛分钟、真实比分、主单和保险单双向比较目标是否已经命中、仍可实现、已经超出；配合最近 5/10 分钟由两个真实有效统计快照计算的射门、射正、禁区射门、xG 增量，以及红牌/比分导致的结构重置。案例：

- 主单1-0，目前1-0，主队最近5分钟继续创造机会 → **主单被2-0威胁**；如果保险2是2-0会说明其仍有可能命中。
- 主单1-0，目前1-0，客队最近5分钟攻势增加 → **主单被1-1威胁**；不臆测未来进球概率。
- 主单1-0，30'仍为0-0，双方累计xG很低、射正/禁区机会少 → **主单尚未实现，需考虑时间与真实结算价**。
- 主单已因比分超过目标而失效 → 分别报告保险单是否还可能命中。
- 无统计、样本过期、没有新数据 → 标记不足，不把单方控球当成必进球信号。

API-FOOTBALL 的 `/fixtures/statistics?fixture=ID&half=true` 在部分联赛没有 xG/危险进攻、早年赛季不支持半场统计；引擎不会补造。OpenAI API Key **选填**，没填仍有纯数据规则提醒。42分钟不是必然盈利点，Cash Out由平台自行决定是否显示与成交。

## 安装方式（新App与原四点版并存）

新应用包名 `com.htlive.monitor.exit42`，显示名 **HT 42分钟结单（独立版）**；**不会覆盖**原包名 `com.htlive.monitor.checkpoints`。新App会有独立的本地存储，因此需要在新App里重新保存 Football Key / OpenAI Key 并授权通知。

### GitHub Actions 用 ZIP 构建（最便于手机操作）

1. 在 <https://github.com/new> 创建**空仓库**，建议仓库名 `HT42ExitCashoutAlerts`，建议 Private，不要初始化 README。
2. 使用仓库网页 **Add file → Upload files** 上传完整的 `HT42ExitMonitor_OneUpload.zip` 到仓库根目录并提交。GitHub 不会自动解压 ZIP；工作流会解压。
3. **Add file → Create new file**，文件路径填 `.github/workflows/build-apk.yml`，把一起提供的单独 `build-apk.yml` 文件内容粘贴提交（或解压 ZIP，把其中 `.github/workflows/build-apk.yml` 直接放进 GitHub 对应目录）。
4. **Actions → Build HT42 Exit Monitor APK → Run workflow → Run workflow**。执行成功后在 Artifacts 找 `HT42ExitMonitor-debug-apk`，下载并解压 `app-debug.apk` 安装。
5. 安装后打开 **接口设置** 保存 API-FOOTBALL Key、可选 OpenAI Key；授权系统通知和后台运行权限。先用一场友谊赛或历史可再现的模拟数据测试，而不是立即依赖它做真实结算。

### 电脑已安装 Android SDK / Gradle

在项目源码根目录运行：

```bash
gradle :app:assembleDebug
```

输出一般在 `app/build/outputs/apk/debug/app-debug.apk`。**提供的是源码，不是已通过真机签名/验证的 APK**。

### 规则单测

```bash
for f in tests/*.test.js; do node "$f"; done
mkdir -p /tmp/ht-tests
javac -encoding UTF-8 -d /tmp/ht-tests app/src/main/java/com/htlive/monitor/AlertPolicy.java tests/java/com/htlive/monitor/AlertPolicyTest.java
java -cp /tmp/ht-tests com.htlive.monitor.AlertPolicyTest
javac -encoding UTF-8 -d /tmp/ht-tests tests/java/org/json/JSONObject.java app/src/main/java/com/htlive/monitor/ScorePlanRiskEngine.java tests/java/com/htlive/monitor/ScorePlanRiskEngineTest.java
java -cp /tmp/ht-tests com.htlive.monitor.ScorePlanRiskEngineTest
```

仅完成源码与规则单测，未在本机运行 Android SDK Gradle 编译或真机通知端到端验证。请特别确认：启动后开赛提示、15'和30'真实数据、42'醒目通知、进球和红牌去重、重开App比分方案保存、设备省电/锁屏情形。API数据和系统通知都可能延迟，**不适合承诺“第42分钟必达”**。
