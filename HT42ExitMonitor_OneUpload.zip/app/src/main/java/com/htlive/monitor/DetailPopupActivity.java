package com.htlive.monitor;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

/** Native modal detail window launched by tapping any heads-up notification. */
public final class DetailPopupActivity extends Activity {
    private TextView content;
    private String fixtureId;
    @Override public void onCreate(Bundle b){super.onCreate(b);render(getIntent());}
    @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);render(i);}
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private void render(Intent intent){
        fixtureId=intent.getStringExtra("id");if(fixtureId==null)fixtureId="";
        getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        WindowManager.LayoutParams params=getWindow().getAttributes();params.dimAmount=.72f;
        getWindow().setAttributes(params);
        LinearLayout layout=new LinearLayout(this);layout.setOrientation(LinearLayout.VERTICAL);layout.setPadding(dp(18),dp(15),dp(18),dp(15));layout.setBackgroundColor(Color.rgb(15,34,51));
        TextView title=new TextView(this);title.setText(intent.getStringExtra("title")!=null?intent.getStringExtra("title"):"赛况详细数据");title.setTextSize(19);title.setTextColor(Color.rgb(87,225,207));title.setTypeface(null,Typeface.BOLD);layout.addView(title);
        TextView hint=new TextView(this);hint.setText("主队 / 客队 · API-FOOTBALL · 仅用于手动结算复核");hint.setTextSize(11);hint.setTextColor(0xffaec3d5);hint.setPadding(0,dp(8),0,dp(8));layout.addView(hint);
        ScrollView scroll=new ScrollView(this);content=new TextView(this);content.setText(intent.getStringExtra("detail")!=null?intent.getStringExtra("detail"):"数据尚未取得");content.setTextColor(Color.WHITE);content.setTextSize(14);content.setLineSpacing(dp(4),1f);content.setTextIsSelectable(true);scroll.addView(content);
        layout.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout buttons=new LinearLayout(this);buttons.setGravity(Gravity.CENTER);buttons.setPadding(0,dp(10),0,0);
        Button refresh=new Button(this);refresh.setText("刷新实时数据");refresh.setOnClickListener(v->refresh());buttons.addView(refresh,new LinearLayout.LayoutParams(0,dp(52),1));
        Button close=new Button(this);close.setText("关闭");close.setOnClickListener(v->finish());buttons.addView(close,new LinearLayout.LayoutParams(0,dp(52),.7f));
        layout.addView(buttons);setContentView(layout);
        getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels*.97), (int)(getResources().getDisplayMetrics().heightPixels*.83));
    }
    private void refresh(){
        if(!fixtureId.matches("[0-9]+")){content.setText("无效比赛ID；请返回应用重新选择。");return;}
        content.setText("正在读取实时比分与双方射门统计…\n需要网络、套餐额度与赛事数据覆盖。");
        new Thread(()->{
            String text;
            try{
                SharedPreferences pref=getSharedPreferences("ht_monitor",MODE_PRIVATE);
                String key=pref.getString("apiKey","");
                JSONObject result=ApiClient.get("fixtures?id="+fixtureId,key);
                JSONArray arr=result.optJSONArray("response");if(arr==null||arr.length()==0)throw new Exception("没有该场赛况，可能尚未开赛或接口不可用");
                JSONObject f=arr.getJSONObject(0),teams=f.optJSONObject("teams");
                int hid=teams.getJSONObject("home").optInt("id"),aid=teams.getJSONObject("away").optInt("id");
                JSONObject stats=MatchData.combine(ApiClient.get("fixtures/statistics?fixture="+fixtureId+"&half=true",key).optJSONArray("response"),hid,aid);
                JSONObject match=MatchData.parseFixture(f,stats);
                text=MatchData.detail(match,System.currentTimeMillis(),"手动刷新 / API-FOOTBALL");
            }catch(Exception e){text="刷新失败："+e.getMessage()+"\n请查看原始提醒或者检查API Key、网络和套餐。";}
            final String show=text;runOnUiThread(()->{if(content!=null)content.setText(show);});
        }).start();
    }
}
