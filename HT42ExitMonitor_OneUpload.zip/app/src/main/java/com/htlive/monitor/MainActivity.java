package com.htlive.monitor;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.net.Uri;
import android.widget.Toast;
import android.webkit.ValueCallback;
import org.json.JSONObject;
import org.json.JSONArray;
import com.google.mlkit.vision.text.Text;
import android.graphics.Rect;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.util.Base64;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> chooserCallback;
    private TextRecognizer recognizerLatin;
    private TextRecognizer recognizerChinese;
    private final ExecutorService network = Executors.newSingleThreadExecutor();
    private static final int FILE_PICK=501;
    private SharedPreferences prefs;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs=getSharedPreferences("ht_monitor",MODE_PRIVATE);
        webView=new WebView(this);
        webView.setBackgroundColor(0xff07101d);
        setContentView(webView);
        WebSettings ws=webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowFileAccessFromFileURLs(false);
        ws.setAllowUniversalAccessFromFileURLs(false);
        ws.setDefaultTextEncodingName("utf-8");
        webView.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest req) {
                return !"file".equalsIgnoreCase(req.getUrl().getScheme());
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (chooserCallback!=null) chooserCallback.onReceiveValue(null);
                chooserCallback=callback;
                try {
                    Intent intent=new Intent(Intent.ACTION_GET_CONTENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("image/*");
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
                    startActivityForResult(Intent.createChooser(intent,"选择下注截图"),FILE_PICK);
                    return true;
                } catch(Exception e){ chooserCallback=null; return false; }
            }
        });
        webView.addJavascriptInterface(new Bridge(),"NativeHT");
        recognizerLatin=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        recognizerChinese=TextRecognition.getClient(new ChineseTextRecognizerOptions.Builder().build());
        webView.loadUrl("file:///android_asset/index.html");
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},102);
        }
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==FILE_PICK && chooserCallback!=null){
            Uri[] uris=null;
            if(resultCode==RESULT_OK && data!=null) {
                if(data.getClipData()!=null){
                    int size=Math.min(12,data.getClipData().getItemCount());
                    uris=new Uri[size];
                    for(int i=0;i<size;i++) uris[i]=data.getClipData().getItemAt(i).getUri();
                } else if(data.getData()!=null) uris=new Uri[]{data.getData()};
            }
            chooserCallback.onReceiveValue(uris); chooserCallback=null;
        }
    }
    /**
     * Screenshot timetable OCR: keep only mint/green kickoff headings or white
     * fixture rows. Yellow reminder timestamps must NEVER become kickoff times.
     * Colors are read from the original pixels, not OCR's guessed strings.
     */
    private static Bitmap colorMask(Bitmap original, boolean mint) {
        int width=original.getWidth(), height=original.getHeight();
        int[] source=new int[width*height], masked=new int[source.length];
        original.getPixels(source,0,width,0,0,width,height);
        int count=0;
        for(int i=0;i<source.length;i++){
            int c=source[i],r=Color.red(c),g=Color.green(c),b=Color.blue(c);
            // Screenshot mint: e.g. RGB(155,240,220). White: (227,237,249).
            // Yellow (245,209,153) fails BOTH tests.
            boolean green=g>=125 && g-r>=25 && g-b>=4 && b>=r+9;
            // Key fix for ID-card screenshots: labels are truly pure white
            // (#FFFFFF), not necessarily blue-tinted white.
            boolean white=r>=165 && g>=165 && b>=165
                    && Math.abs(r-g)<=25 && Math.abs(g-b)<=25
                    && Math.abs(r-b)<=25 && r+g+b>=540 && !green;
            boolean accept=mint?green:white;
            masked[i]=accept?Color.BLACK:Color.WHITE;
            if(accept)count++;
        }
        Bitmap out=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);
        out.setPixels(masked,0,width,0,0,width,height);
        return out;
    }
    private static void extractOcrLines(Text text, JSONArray output,String source,String color){
        if(text==null)return;
        try {
            for(Text.TextBlock block:text.getTextBlocks())for(Text.Line line:block.getLines()){
                Rect r=line.getBoundingBox();if(r==null||line.getText().trim().isEmpty())continue;
                output.put(new JSONObject().put("t",line.getText()).put("x",r.left).put("y",r.top)
                    .put("w",r.width()).put("h",r.height()).put("source",source).put("color",color));
            }
        }catch(Exception ignored){}
    }
    private void sendOcrResult(String photoId,JSONArray lines,String priorError){
        StringBuilder b=new StringBuilder();
        for(int i=0;i<lines.length();i++){
            JSONObject line=lines.optJSONObject(i);
            if(line!=null){if(b.length()>0)b.append('\n');b.append(line.optString("t"));}
        }
        String error=b.length()>0?"":priorError;
        js("window.nativeOcrDone("+JSONObject.quote(photoId)+","+JSONObject.quote(b.toString())+","+JSONObject.quote(error)+","+JSONObject.quote(lines.toString())+")");
    }
    private void js(String expression){runOnUiThread(()->webView.evaluateJavascript(expression,null));}
    public class Bridge {
        @JavascriptInterface public String getKey(){return prefs.getString("apiKey","");}
        @JavascriptInterface public String getAiKey(){return prefs.getString("openaiKey","");}
        @JavascriptInterface public void saveAiKey(String key){prefs.edit().putString("openaiKey",key==null?"":key.trim()).apply();}
        @JavascriptInterface public void saveKey(String key){prefs.edit().putString("apiKey",key.trim()).apply();}
        @JavascriptInterface public String state(){
            JSONObject result=new JSONObject();
            try {
                result.put("running",prefs.getBoolean("running",false));
                result.put("snapshot",new JSONObject(prefs.getString("snapshot","{}")));
                result.put("alerts",new org.json.JSONArray(prefs.getString("alerts","[]")));
                result.put("checkpoints",new JSONArray(prefs.getString("checkpoints","[]")));
                result.put("ids",prefs.getString("watchIds",""));
                result.put("interval",prefs.getInt("interval",60));
                result.put("autoPruned",new JSONArray(prefs.getString("autoPruned","[]")));
                result.put("mainPicks",new JSONObject(prefs.getString("mainPicks","{}")));
                result.put("scorePlans",new JSONObject(prefs.getString("scorePlans","{}")));
            }catch(Exception ignored){}
            return result.toString();
        }
        /** One optional exact-score target per fixture. Stored locally, never in a public ZIP. */
        @JavascriptInterface public String saveMainPick(String fixtureId,String score){
            if(fixtureId==null || !fixtureId.matches("[0-9]{1,12}"))return "比赛ID无效";
            String pick=score==null?"":score.trim().replace('：','-').replace(':','-');
            if(!pick.isEmpty() && !MainScoreRiskEngine.validPick(pick))return "请输入 1-0、0-0、0-1 等主:客比分（0–9）";
            synchronized(MainActivity.this){
                try{
                    JSONObject picks=new JSONObject(prefs.getString("mainPicks","{}"));
                    if(pick.isEmpty())picks.remove(fixtureId);else picks.put(fixtureId,pick);
                    JSONObject plans=new JSONObject(prefs.getString("scorePlans","{}"));
                    JSONObject plan=plans.optJSONObject(fixtureId);
                    if(plan==null)plan=ScorePlanRiskEngine.normalize(null);
                    plan.put("main",pick);plans.put(fixtureId,plan);
                    if(!prefs.edit().putString("mainPicks",picks.toString()).putString("scorePlans",plans.toString()).commit())return "保存失败，请重试";
                }catch(Exception ex){return "保存失败："+ex.getMessage();}
            }
            return "OK";
        }
        /** Main + one/two insurance exact-score targets (2 by default).
         *  Validated and committed atomically with legacy mainPicks for older views. */
        @JavascriptInterface public String saveScorePlan(String fixtureId,String json){
            if(fixtureId==null || !fixtureId.matches("[0-9]{1,12}"))return "比赛ID无效";
            try{
                JSONObject plan=ScorePlanRiskEngine.normalize(new JSONObject(json));
                synchronized(MainActivity.this){
                    JSONObject plans=new JSONObject(prefs.getString("scorePlans","{}"));
                    JSONObject main=new JSONObject(prefs.getString("mainPicks","{}"));
                    plans.put(fixtureId,plan);
                    String target=plan.optString("main","");
                    if(target.isEmpty())main.remove(fixtureId);else main.put(fixtureId,target);
                    if(!prefs.edit().putString("scorePlans",plans.toString())
                        .putString("mainPicks",main.toString()).commit())return "保存失败";
                }
                return "OK";
            }catch(Exception e){return "保存失败/格式无效："+e.getMessage();}
        }
        @JavascriptInterface public void request(String rid,String path,String key){
            network.execute(()->{
                String raw;
                try { raw=ApiClient.get(path,key).toString(); }
                catch(Exception e){ try {JSONObject err=new JSONObject();err.put("_error",e.getMessage());raw=err.toString();}catch(Exception x){raw="{\"_error\":\"请求失败\"}";} }
                js("window.nativeDone("+JSONObject.quote(rid)+","+JSONObject.quote(raw)+")");
            });
        }
        @JavascriptInterface public void setInterval(int seconds){
            prefs.edit().putInt("interval",Math.max(30,Math.min(300,seconds))).apply();
        }
        @JavascriptInterface public void start(String csv,int interval){
            String key=prefs.getString("apiKey","");
            if(key.isEmpty()) { js("window.nativeToast('请先保存API Key')"); return; }
            if(csv==null || !csv.matches("[0-9]+(,[0-9]+){0,11}")){js("window.nativeToast('请先选择1至12场比赛')");return;}
            int seconds=Math.max(30,Math.min(300,interval));
            prefs.edit().putString("watchIds",csv).putInt("interval",seconds).apply();
            Intent intent=new Intent(MainActivity.this,MonitorService.class).setAction("START");
            try { androidxFallbackStart(intent); js("window.nativeToast('监控已启动')"); }
            catch(Exception e){js("window.nativeToast("+JSONObject.quote("启动失败："+e.getMessage())+")");}
        }
        @JavascriptInterface public String updateWatchlist(String csv){
            if(csv==null) return "比赛名单无效";
            if(!csv.isEmpty() && !csv.matches("[0-9]+(,[0-9]+){0,11}")) return "最多只能监控12场有效比赛";
            prefs.edit().putString("watchIds",csv).apply();
            if(csv.isEmpty()){
                prefs.edit().putBoolean("autoArmFromImage",false).apply();
                Intent intent=new Intent(MainActivity.this,MonitorService.class).setAction("STOP");
                startService(intent);
            }
            // The foreground worker reads watchIds on its next polling cycle.
            // New fixtures establish a baseline before generating event alerts.
            return "OK";
        }
        /** Called only after screenshot IDs have been verified against API-FOOTBALL.
         * Queue the fixture reminders and arm automatic live polling near kickoff.
         */
        @JavascriptInterface public String armImportedMatches(String csv,String matchesJson,int requestedInterval){
            if(csv==null||!csv.matches("[0-9]+(,[0-9]+){0,11}"))return "ERROR:监控比赛ID不合法";
            if(prefs.getString("apiKey","").trim().isEmpty())return "ERROR:请先保存API Key";
            try {
                JSONArray matches=new JSONArray(matchesJson);
                if(matches.length()==0)return "ERROR:观察名单为空";
                boolean imminent=false,scheduled=false;
                long now=System.currentTimeMillis();
                for(int k=0;k<matches.length();k++){
                    JSONObject m=matches.optJSONObject(k);if(m==null)continue;
                    long kickoff;
                    try { kickoff=java.time.OffsetDateTime.parse(m.optString("kickoff")).toInstant().toEpochMilli(); }
                    catch(Exception ex){continue;}
                    // Starts at most ten minutes before kickoff; don't consume 6-hour
                    // Android 15 data-sync service budget on a next-day fixture.
                    if(kickoff>=now-55L*60_000L && kickoff<=now+10L*60_000L)imminent=true;
                    if(kickoff>now+10L*60_000L)scheduled=true;
                }
                prefs.edit().putString("watchIds",csv)
                    .putBoolean("autoArmFromImage",true)
                    .putInt("interval",Math.max(30,Math.min(300,requestedInterval))).apply();
                ReminderReceiver.schedule(MainActivity.this,matchesJson);
                if(imminent){
                    // Explicitly call onStartCommand even if an old 'running' flag
                    // survived process death. The service itself is idempotent.
                    androidxFallbackStart(new Intent(MainActivity.this,MonitorService.class).setAction("START"));
                    return "STARTED";
                }
                return scheduled?"ARMED":"ERROR:比赛已超过上半场观察窗口";
            }catch(Exception e){return "ERROR:"+e.getMessage();}
        }
        @JavascriptInterface public void stop(){
            prefs.edit().putBoolean("autoArmFromImage",false).apply();
            Intent intent=new Intent(MainActivity.this,MonitorService.class).setAction("STOP");
            startService(intent);
            js("window.nativeToast('监控已停止')");
        }
        @JavascriptInterface public void notifyTest(){
            try {
                JSONObject x=new JSONObject().put("id","0").put("home","演示主队").put("away","演示客队")
                  .put("status","1H").put("minute",25).put("h",0).put("a",0).put("trend","主队近5分钟压制");
                JSONObject h=new JSONObject().put("xg",0.65).put("shots",5).put("on",2).put("box",3).put("pos",58);
                JSONObject a=new JSONObject().put("xg",0.18).put("shots",2).put("on",1).put("box",1).put("pos",42);
                x.put("stats",new JSONObject().put("available",true).put("home",h).put("away",a));
                x.put("goalWarning",new JSONObject().put("level","strong").put("rating","B级")
                    .put("title","演示主队持续施压 · 可能出现进球机会")
                    .put("reason","演示数据：最近5分钟射门+4、射正+2、禁区射门+3，非真实比赛")
                    .put("momentum","演示：近10分钟持续占优")
                    .put("risk","这是通知样式测试，不是赛事判断"));
                AlertNotifier.post(MainActivity.this,"模拟进球预警（演示数据，不是真实比赛）","0",x,System.currentTimeMillis(),"");
            } catch(Exception e){js("window.nativeToast("+JSONObject.quote("通知测试失败："+e.getMessage())+")");}
        }
        @JavascriptInterface public void scheduleReminders(String matchesJson){
            try {ReminderReceiver.schedule(MainActivity.this,matchesJson);}
            catch(Exception e){js("window.nativeToast("+JSONObject.quote("安排节点提醒失败："+e.getMessage())+")");}
        }
        @JavascriptInterface public void ocr(String photoId,String base64Data){
            network.execute(()->{
                try {
                    if(base64Data==null||base64Data.length()>12_000_000)throw new Exception("图片太大");
                    int comma=base64Data.indexOf(',');
                    if(comma<0)throw new Exception("无效图片格式");
                    byte[] image=Base64.decode(base64Data.substring(comma+1),Base64.DEFAULT);
                    Bitmap bitmap=BitmapFactory.decodeByteArray(image,0,image.length);
                    if(bitmap==null)throw new Exception("无法解析图像");
                    // Two independent OCR streams; on this screenshot format the headers
                    // are green Chinese/date, while English team names are white.
                    Bitmap heading=colorMask(bitmap,true);
                    Bitmap teams=colorMask(bitmap,false);
                    InputImage greenInput=InputImage.fromBitmap(heading,0);
                    InputImage whiteInput=InputImage.fromBitmap(teams,0);
                    recognizerChinese.process(greenInput).addOnCompleteListener(greenTask->{
                        recognizerLatin.process(whiteInput).addOnCompleteListener(whiteTask->{
                            JSONArray lines=new JSONArray();
                            if(greenTask.isSuccessful())extractOcrLines(greenTask.getResult(),lines,"chinese","green");
                            if(whiteTask.isSuccessful())extractOcrLines(whiteTask.getResult(),lines,"latin","white");
                            // Return bounding boxes; JS sorts green headers and white fixtures
                            // into the ORIGINAL screenshot order before matching the API.
                            String content="";
                            for(int i=0;i<lines.length();i++){
                                JSONObject line=lines.optJSONObject(i);
                                if(line!=null)content+=(content.isEmpty()?"":"\n")+line.optString("t");
                            }
                            String err=lines.length()==0?"没有读到绿色开赛标题或白色比赛名称，请使用原始清晰图片":"";
                            final String primary=content;
                            final String primaryError=err;
                            if(!java.util.regex.Pattern.compile("(?i)fixture\\s*(?:id|1d)?\\s*[:#-]?\\s*[0-9]{5,10}").matcher(primary).find()){
                                // Extra pass rescues thin white Fixture-ID glyphs on dark JPEGs.
                                recognizerLatin.process(InputImage.fromBitmap(bitmap,0)).addOnCompleteListener(fullTask->{
                                    if(fullTask.isSuccessful()){
                                        JSONArray fallback=new JSONArray();
                                        extractOcrLines(fullTask.getResult(),fallback,"original","white");
                                        for(int q=0;q<fallback.length();q++){
                                            JSONObject row=fallback.optJSONObject(q);if(row==null)continue;
                                            String t=row.optString("t");
                                            if(!t.toLowerCase(java.util.Locale.ROOT).contains("fixture")
                                                && !t.matches("(?i).*\\bvs\\b.*"))continue;
                                            boolean exists=false;
                                            for(int i=0;i<lines.length();i++){
                                                JSONObject existing=lines.optJSONObject(i);
                                                if(existing!=null && Math.abs(existing.optInt("y")-row.optInt("y"))<12
                                                    && existing.optString("t").length()>=t.length()/2){exists=true;break;}
                                            }
                                            if(!exists)lines.put(row);
                                        }
                                    }
                                    sendOcrResult(photoId,lines,primaryError);
                                    heading.recycle();teams.recycle();bitmap.recycle();
                                });
                            }else{
                                sendOcrResult(photoId,lines,primaryError);
                                heading.recycle();teams.recycle();bitmap.recycle();
                            }
                        });
                    });
                }catch(Exception e){js("window.nativeOcrDone("+JSONObject.quote(photoId)+",\"\","+JSONObject.quote(e.getMessage())+")");}
            });
        }
        @JavascriptInterface public void requestNotification(){
            if(Build.VERSION.SDK_INT>=33){runOnUiThread(()->{if(checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},102);});}
        }
    }
    private void androidxFallbackStart(Intent i){
        if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);
    }
    @Override public void onBackPressed(){ if(webView!=null && webView.canGoBack())webView.goBack();else super.onBackPressed(); }
    @Override protected void onDestroy(){
        if(chooserCallback!=null){chooserCallback.onReceiveValue(null);chooserCallback=null;}
        network.shutdownNow();
        if(recognizerLatin!=null)recognizerLatin.close();
        if(recognizerChinese!=null)recognizerChinese.close();
        if(webView!=null){webView.removeJavascriptInterface("NativeHT");webView.destroy();}
        super.onDestroy();
    }
}
