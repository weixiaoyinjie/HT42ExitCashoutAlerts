package com.htlive.monitor;

/** Half-time cleanup is status-driven, not wall-clock driven. */
public final class MatchLifecycle {
    private MatchLifecycle() {}
    public static boolean shouldPrune(String status){
        if(status==null)return false;
        switch(status){
            case "HT": case "2H": case "FT": case "AET": case "PEN":
            case "CANC": case "PST": case "ABD": case "AWD": case "WO":
                return true;
            default: return false;
        }
    }
}
