package com.htlive.monitor;

import org.json.JSONObject;

/** Evidence-led, score-specific early cash-out review. Never a goal forecast or an order. */
public final class MainScoreRiskEngine {
    private MainScoreRiskEngine() {}
    public static boolean validPick(String pick){return pick!=null && pick.matches("[0-9]-[0-9]");}
    private static double n(JSONObject j,String key){
        if(j==null || j.isNull(key))return Double.NaN;
        double v=j.optDouble(key,Double.NaN);
        return Double.isFinite(v)&&v>=0?v:Double.NaN;
    }
    private static boolean known(double n){return Double.isFinite(n);}
    private static String fmt(double d){return known(d)?(Math.round(d*100.0)/100.0)+"":"—";}
    private static String stat(JSONObject h,JSONObject a,String field){return fmt(n(h,field))+"/"+fmt(n(a,field));}
    private static boolean grew(JSONObject current,JSONObject previous,String field){
        double a=n(current,field),b=n(previous,field);
        return known(a)&&known(b)&&a>b+(.0001);
    }
    private static JSONObject base(String pick){
        try{return new JSONObject().put("mainPick",pick).put("notify",false)
                .put("kind","none").put("level","PASS")
                .put("rating","PASS").put("title","待实时数据复核");}
        catch(Exception e){return new JSONObject();}
    }
    private static JSONObject warning(JSONObject out,String kind,String level,String side,String title,String reason)throws Exception{
        return out.put("kind",kind).put("level",level).put("rating",level.equals("strong")?"B级":"C级")
                .put("side",side).put("notify",true).put("title",title).put("reason",reason)
                .put("caution","仅用于提前核对平台结算报价；没有接入真实结算金额，不能据此自动结单。");
    }
    /** Given a selected exact first-half score, reason about the actual scoreboard + fresh statistics. */
    public static JSONObject analyze(JSONObject match,JSONObject previous,String pick,long now)throws Exception{
        JSONObject out=base(pick);
        if(!validPick(pick) || !"1H".equals(match.optString("status")))return out;
        int th=pick.charAt(0)-'0',ta=pick.charAt(2)-'0';
        int h=match.optInt("h",-1),a=match.optInt("a",-1),minute=match.optInt("minute",-1);
        if(h<0||a<0)return out;
        boolean exact=h==th&&a==ta,broken=h>th||a>ta;
        out.put("scoreState",broken?"broken":exact?"hit":"open");
        if(broken){
            return warning(out,"broken","strong","both","主单"+pick+"已超出 · 立即核对",
                "场上"+h+"-"+a+"，主单准确比分"+pick+"已无法恢复；如另有注单，请分别核对。此提醒不是结算指令。");
        }
        boolean scoreJustHit=exact && !(th==0 && ta==0 && minute<25) &&
            (previous==null || !pick.equals(previous.optString("mainPick","")) || h!=previous.optInt("h",-1)||a!=previous.optInt("a",-1));
        JSONObject st=match.optJSONObject("stats");
        boolean fresh=match.optLong("lastStatsAt",0)>0&&now-match.optLong("lastStatsAt")<=90_000L;
        if(st==null || !st.optBoolean("available") || !fresh || match.has("dataError")){
            if(scoreJustHit) return warning(out,"justHit","watch","both","主单"+pick+"比分已命中 · 复核报价",
                "当前"+h+"-"+a+"符合主单。下一球会令主单准确比分失效；实时统计不可用，不能判断下一球方向。");
            return out.put("title","主单"+pick+" · 数据未就绪，暂停趋势判断");
        }
        JSONObject home=st.optJSONObject("home"),away=st.optJSONObject("away");
        if(home==null||away==null)return out;
        JSONObject oldStats=previous==null?null:previous.optJSONObject("stats");
        boolean stableScore=previous!=null&&h==previous.optInt("h",-1)&&a==previous.optInt("a",-1);
        String winner="",strength="",proof="";
        double highest=0;
        for(String side:new String[]{"home","away"}){
            JSONObject lead="home".equals(side)?home:away,lag="home".equals(side)?away:home;
            double xg=n(lead,"xg"),ox=n(lag,"xg"),on=n(lead,"on"),oo=n(lag,"on");
            double box=n(lead,"box"),ob=n(lag,"box"),pos=n(lead,"pos");
            double shots=n(lead,"shots"),os=n(lag,"shots");
            boolean xgGap=known(xg)&&known(ox)&&xg-ox>=.22;
            boolean onGap=known(on)&&known(oo)&&on-oo>=2;
            boolean boxGap=known(box)&&known(ob)&&box-ob>=1;
            boolean posGap=known(pos)&&pos>=62;
            boolean shotGap=known(shots)&&known(os)&&shots-os>=2;
            boolean reinforced= (xgGap&&(onGap||boxGap||posGap||shotGap)) ||
                (onGap&&(boxGap||posGap||shotGap)) ||
                (posGap&&shotGap && shots>=3) ||
                (boxGap&&shotGap&&known(on)&&known(oo)&&on>=oo);
            // Treat 5/5 shots with 0/2 on-target and .07/.37 xG as a genuine warning.
            if(!reinforced)continue;
            double rank=(xgGap?5:0)+(onGap?4:0)+(boxGap?2:0)+(posGap?2:0)+(shotGap?2:0)
                +(known(xg)&&known(ox)?Math.min(3,(xg-ox)*4):0);
            if(rank>highest){
                highest=rank;winner=side;strength=rank>=9?"strong":"watch";
                proof=(side.equals("home")?"主队":"客队")+"优势：xG "+stat(home,away,"xg")+
                  "，射门 "+stat(home,away,"shots")+"，射正 "+stat(home,away,"on")+
                  "，禁区内 "+stat(home,away,"box")+"，控球 "+stat(home,away,"pos")+"（均为主/客）。";
            }
        }
        String current=h+"-"+a;
        if(exact){
            if(scoreJustHit){
                return warning(out,"justHit","strong","both","主单"+pick+"已命中 · 立即复核结算",
                  "场上"+current+"正好符合主单，任一方再进球都将使该准确比分失效。"+
                  (!winner.isEmpty()?proof:"暂未观察到可靠压制，不能据此预测下一球。"));
            }
            // One-goal lead still shooting after it has scored: pre-goal shots must not be reused.
            for(String side:new String[]{"home","away"}){
                JSONObject currentSide="home".equals(side)?home:away;
                JSONObject oldSide=oldStats==null?null:oldStats.optJSONObject(side);
                if(stableScore&&oldSide!=null &&
                    (grew(currentSide,oldSide,"shots")||grew(currentSide,oldSide,"on")||grew(currentSide,oldSide,"box")||grew(currentSide,oldSide,"xg"))){
                    String team=side.equals("home")?"主队":"客队";
                    return warning(out,"atScoreNewAttack","strong",side,"主单"+pick+"命中后有新攻势 · 立即复核",
                        "场上"+current+"，"+team+"在相同比分的连续采样间产生新增机会；下一球会破坏主单。"+
                        "最新主/客：xG "+stat(home,away,"xg")+"，射正 "+stat(home,away,"on")+
                        "，禁区内 "+stat(home,away,"box")+"。请检查是否值得结算。");
                }
            }
            if(!winner.isEmpty())return warning(out,"atScoreAdvantage",strength,winner,
                "主单"+pick+"已命中 · "+(winner.equals("home")?"主队":"客队")+"数据占优",
                "当前"+current+"已符合主单，下一球对主单不利。"+proof+
                "累计数据不一定是进球后攻势，需核对最近5分钟变化。");
            return out.put("title","主单"+pick+"已命中，暂未新增危险优势");
        }
        if(!winner.isEmpty()){
            boolean against=(winner.equals("home")?h>=th:a>=ta);
            return warning(out,"sideAdvantage",strength,winner,
                "主单"+pick+" · "+(winner.equals("home")?"主队":"客队")+"明显占优 · 预判提醒",
                "当前"+current+"，"+(against?"优势方再进球将使主单无法命中。":"目标尚未到位，比赛优势结构已改变。")+proof+
                "请结合平台结算报价决定是否提前退出。");
        }
        // Dull scoreless game: relevant to a pick needing at least one goal, not a 0-0 pick.
        double hx=n(home,"xg"),ax=n(away,"xg"),hs=n(home,"shots"),as=n(away,"shots");
        double hon=n(home,"on"),aon=n(away,"on"),hb=n(home,"box"),ab=n(away,"box");
        boolean dull=minute>=26 && h==0&&a==0 && (th>0||ta>0) &&
            known(hx)&&known(ax)&&hx<=.19&&ax<=.19&&
            known(hs)&&known(as)&&hs+as<=6 &&
            known(hon)&&known(aon)&&hon+aon<=1 &&
            known(hb)&&known(ab)&&hb+ab<=3;
        if(dull){return warning(out,"quiet","watch","both","主单"+pick+"仍未出现 · 比赛沉闷预警",
              minute+"′仍0-0，xG "+stat(home,away,"xg")+"、射门 "+stat(home,away,"shots")+
                "、射正 "+stat(home,away,"on")+"，双方有效机会偏少，主单尚需进球。请考虑时间和结算价。");}
        return out.put("title","主单"+pick+" · 未出现需额外推送的新风险");
    }
    /** Notify on the first meaningful condition, a changed score/pick/direction, or fresh evidence after cooldown. */
    public static boolean shouldNotify(JSONObject current,JSONObject prev,long now){
        JSONObject risk=current.optJSONObject("mainPickRisk");
        if(risk==null||!risk.optBoolean("notify")||!"1H".equals(current.optString("status")))return false;
        if(prev==null)return true;
        String pick=current.optString("mainPick"),oldPick=prev.optString("mainPick");
        if(!pick.equals(oldPick))return true;
        JSONObject prior=prev.optJSONObject("mainPickRisk");
        if(prior==null || current.optInt("h")!=prev.optInt("h") ||
            current.optInt("a")!=prev.optInt("a"))return true;
        boolean changedKind=!risk.optString("kind").equals(prior.optString("kind"));
        boolean changedSide=!risk.optString("side").equals(prior.optString("side"));
        if(changedKind||changedSide){
            if("quiet".equals(risk.optString("kind")) || "broken".equals(risk.optString("kind")) ||
                "justHit".equals(risk.optString("kind")))return true;
            // Do not issue a second alert for the same static cumulative statistics.
            JSONObject nStats=current.optJSONObject("stats"),pStats=prev.optJSONObject("stats");
            if(nStats==null||pStats==null)return false;
            for(String side:new String[]{"home","away"}){
                JSONObject nSide=nStats.optJSONObject(side),pSide=pStats.optJSONObject(side);
                for(String fld:new String[]{"shots","on","box","xg"})
                    if(grew(nSide,pSide,fld))return true;
            }
            return false;
        }
        long priorSent=prev.optLong("lastMainRiskNotifyAt",0L);
        if(priorSent<=0)return true;
        long cool=current.optInt("minute")>=40?90_000L:180_000L;
        if(now-priorSent<cool)return false;
        String kind=risk.optString("kind");
        if("quiet".equals(kind)||"broken".equals(kind)||"justHit".equals(kind))return false;
        String side=risk.optString("side");
        JSONObject ns=current.optJSONObject("stats"),ps=prev.optJSONObject("stats");
        if(ns==null||ps==null)return false;
        if("both".equals(side))return false;
        JSONObject nSide=ns.optJSONObject(side),pSide=ps.optJSONObject(side);
        if(nSide==null||pSide==null)return false;
        for(String f:new String[]{"shots","on","box","xg"})if(grew(nSide,pSide,f))return true;
        return false;
    }
}
