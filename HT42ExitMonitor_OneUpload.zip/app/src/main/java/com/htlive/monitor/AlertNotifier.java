package com.htlive.monitor;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import java.util.Set;
import java.util.HashSet;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;

/** High-importance heads-up alert with expanded data and a native, scrollable detail popup. */
public final class AlertNotifier {
    private static final String CHANNEL="ht_detail_popup_v14";
    private AlertNotifier(){}
    private static void channel(Context c){
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel ch=new NotificationChannel(CHANNEL,"开赛/15/30/42分钟 · 结单预警",NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("开赛、15/30/42分钟、进球、红牌及重要比分风险；42分钟需手动核对结单。");
        ch.enableVibration(true);ch.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
        nm.createNotificationChannel(ch);
    }
    static void post(Context ctx,String type,String id,JSONObject match,long at,String fallback){
        emit(ctx,type,id,match,at,fallback,true);
    }
    static void update(Context ctx,String type,String id,JSONObject match,long at){
        emit(ctx,type,id,match,at,"",false);
    }
    /** Remove completed fixture notifications, alert history and 4-point snapshots. */
    static void purgeFinished(Context ctx,Set<String> ids){
        if(ids==null || ids.isEmpty())return;
        SharedPreferences p=ctx.getSharedPreferences("ht_monitor",Context.MODE_PRIVATE);
        NotificationManager nm=(NotificationManager)ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        synchronized(AlertNotifier.class){
            try{
                JSONArray oldAlerts=new JSONArray(p.getString("alerts","[]")),keepAlerts=new JSONArray();
                JSONArray oldPoints=new JSONArray(p.getString("checkpoints","[]")),keepPoints=new JSONArray();
                for(int i=0;i<oldAlerts.length();i++){
                    JSONObject item=oldAlerts.optJSONObject(i);
                    // A legacy notification may lack a fixture ID: preserve it, do not guess.
                    if(item!=null && !ids.contains(item.optString("id")))keepAlerts.put(item);
                }
                for(int i=0;i<oldPoints.length();i++){
                    JSONObject item=oldPoints.optJSONObject(i);
                    if(item!=null && !ids.contains(item.optString("id")))keepPoints.put(item);
                }
                JSONObject mainPicks=new JSONObject(p.getString("mainPicks","{}"));
                JSONObject scorePlans=new JSONObject(p.getString("scorePlans","{}"));
                for(String id:ids){mainPicks.remove(id);scorePlans.remove(id);}
                SharedPreferences.Editor edit=p.edit().putString("mainPicks",mainPicks.toString())
                    .putString("scorePlans",scorePlans.toString())
                    .putString("alerts",keepAlerts.toString())
                    .putString("checkpoints",keepPoints.toString());
                for(String id:ids){
                    JSONArray posted=new JSONArray(p.getString("notice_ids_"+id,"[]"));
                    for(int i=0;i<posted.length();i++)nm.cancel(posted.optInt(i));
                    edit.remove("notice_ids_"+id);
                    for(int minute:AlertPolicy.MARKS)edit.remove("delivered_"+id+"_"+minute);
                }
                edit.commit();
            }catch(Exception ex){android.util.Log.w("HT","Finished record cleanup",ex);}
        }
    }
    private static void emit(Context ctx,String type,String id,JSONObject match,long at,String fallback,boolean recordHistory){
        try {
            channel(ctx);
            String detail=match==null?fallback:MatchData.detail(match,at,"API-FOOTBALL 上半场统计");
            if(detail==null||detail.isEmpty())detail="实时数据暂不可用，请检查接口和比分。";
            String title=type+" · "+(match!=null?match.optString("home","主队")+" vs "+match.optString("away","客队"):"比赛 #"+id);
            String brief=match==null?fallback:MatchData.shortSummary(match,at);
            String expanded=match==null?fallback:MatchData.notificationBody(match,at);
            if(match!=null && fallback!=null && !fallback.trim().isEmpty()){
                expanded="事件依据："+fallback+"\n"+expanded;
                detail="事件依据："+fallback+"\n\n"+detail;
            }
            int nid=6200+Math.abs((id+":"+type).hashCode()%800_000);
            Intent open=new Intent(ctx,DetailPopupActivity.class);
            open.setAction("DETAIL_"+nid);open.putExtra("title",title);open.putExtra("detail",detail);open.putExtra("id",id);
            open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pi=PendingIntent.getActivity(ctx,nid,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            Notification b=new Notification.Builder(ctx,CHANNEL).setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title).setContentText(brief)
                .setStyle(new Notification.BigTextStyle().bigText(expanded))
                .setPriority(Notification.PRIORITY_HIGH).setCategory(Notification.CATEGORY_REMINDER)
                .setVisibility(Notification.VISIBILITY_PRIVATE).setAutoCancel(true).setOnlyAlertOnce(true).setContentIntent(pi)
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_info_details,"查看完整数据弹窗",pi).build())
                .setWhen(System.currentTimeMillis()).build();
            ((NotificationManager)ctx.getSystemService(Context.NOTIFICATION_SERVICE)).notify(nid,b);
            if(recordHistory){
                // Per-fixture bookkeeping also lets the HT cleanup cancel all old banners.
                synchronized(AlertNotifier.class){
                    SharedPreferences p=ctx.getSharedPreferences("ht_monitor",Context.MODE_PRIVATE);
                    JSONArray prev=new JSONArray(p.getString("alerts","[]")),list=new JSONArray();
                    list.put(new JSONObject().put("id",id).put("time",System.currentTimeMillis()).put("title",title).put("detail",expanded));
                    for(int i=0;i<Math.min(79,prev.length());i++)list.put(prev.get(i));
                    JSONArray sent=new JSONArray(p.getString("notice_ids_"+id,"[]"));
                    boolean found=false;
                    for(int i=0;i<sent.length();i++)if(sent.optInt(i)==nid){found=true;break;}
                    if(!found)sent.put(nid);
                    p.edit().putString("alerts",list.toString()).putString("notice_ids_"+id,sent.toString()).apply();
                }
            }
        }catch(Exception e){ android.util.Log.e("HT","Failed to post alert",e); }
    }
    /** Four data-backed snapshots: kickoff, 15, 30 and 42; removed at halftime. */
    static String markTitle(int mark){
        return mark==0?"⚽ 开赛 · 比赛观察开始":mark==42?
            "⏰ 第42分钟 · 立即核对手动结单":
            "第"+mark+"分钟 · 比分组合与结单复核";
    }
    public static void saveCheckpoint(Context ctx,String id,int mark,JSONObject match,long at){
        try{
            SharedPreferences p=ctx.getSharedPreferences("ht_monitor",Context.MODE_PRIVATE);
            JSONArray old=new JSONArray(p.getString("checkpoints","[]")),updated=new JSONArray();
            JSONObject c=new JSONObject().put("id",id).put("mark",mark)
                .put("capturedAt",System.currentTimeMillis())
                .put("sourceAt",match!=null && match.optLong("lastStatsAt",0)>0?match.optLong("lastStatsAt"):at)
                .put("status",match==null?"?":match.optString("status","?"))
                .put("minute",match==null?-1:match.optInt("minute",-1))
                .put("home",match==null?"":match.optString("home",""))
                .put("away",match==null?"":match.optString("away",""))
                .put("score",match==null?"?":match.optString("h","?")+"-"+match.optString("a","?"))
                .put("trend",match==null?"无可用样本":match.optString("trend","无可用样本"))
                .put("sampleMissing",match==null || match.optLong("lastStatsAt",0)<=0 || at-match.optLong("lastStatsAt",0)>90_000L)
                .put("cashout","未接入平台结算报价，无法计算各单结算金额");
            if(match!=null){
                JSONObject stats=match.optJSONObject("stats"),delta=match.optJSONObject("delta");
                if(stats!=null)c.put("stats",stats);
                if(delta!=null)c.put("delta",delta);
                JSONObject warning=match.optJSONObject("goalWarning");
                if(warning!=null)c.put("goalWarning",warning);
                JSONObject ai=match.optJSONObject("aiReview");
                if(ai!=null)c.put("aiReview",ai);
                if(match.optJSONObject("scorePlan")!=null)c.put("scorePlan",match.optJSONObject("scorePlan"));
                if(match.optJSONObject("scorePlanRisk")!=null)c.put("scorePlanRisk",match.optJSONObject("scorePlanRisk"));
            }
            updated.put(c);
            for(int i=0;i<old.length() && updated.length()<80;i++){
                JSONObject item=old.optJSONObject(i);
                if(item==null || (id.equals(item.optString("id")) && mark==item.optInt("mark")))continue;
                updated.put(item);
            }
            p.edit().putString("checkpoints",updated.toString()).apply();
        }catch(Exception e){android.util.Log.w("HT","save checkpoint",e);}
    }
    static boolean postMark(Context ctx,String id,int mark,JSONObject match,long at){
        if(match==null || !AlertPolicy.checkpointFresh(
            System.currentTimeMillis(),match.optLong("fixtureSampledAt",0L),
            match.optString("status"),match.optInt("minute",0),mark))return false;
        SharedPreferences p=ctx.getSharedPreferences("ht_monitor",Context.MODE_PRIVATE);
        String key="delivered_"+id+"_"+mark;
        if(p.getBoolean(key,false))return false;
        if(!p.edit().putBoolean(key,true).commit())return false;
        saveCheckpoint(ctx,id,mark,match,at);
        boolean stale=match==null || match.optJSONObject("stats")==null ||
            !match.optJSONObject("stats").optBoolean("available",false) ||
            match.optLong("lastStatsAt",0L)<=0 ||
            System.currentTimeMillis()-match.optLong("lastStatsAt",0L)>90_000L;
        post(ctx,markTitle(mark),id,match,at,
            (mark==42?"【42分钟固定结单提醒】请立即打开投注平台查看各张单可否提前结算。此App不会替你成交；平台可能暂停或拒绝结算。\n":"")+
            (stale?"当前比赛统计缺失或滞后，只能确认比分及比赛分钟；不要依据旧统计判断。":""));
        return true;
    }
}
