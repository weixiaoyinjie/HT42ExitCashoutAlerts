package com.htlive.monitor;

/** Pure, side-effect-free dispatch rules for the limited-alert companion app. */
final class AlertPolicy {
    static final int[] MARKS={0,15,30,42};
    private AlertPolicy(){}

    /** Never invent kickoff or checkpoints from cached or pre-kickoff clocks.
     *  A new monitor may legitimately join during the current mark's minute. */
    static boolean checkpointDue(int previousMinute,int minute,int mark){
        if(!isMark(mark) || minute<mark || previousMinute>=mark)return false;
        // Android/API lag may postpone a node slightly, but never replay it
        // many minutes later when a device wakes from deep sleep.
        return minute<=mark+2;
    }
    /** A delayed OS alarm is not sufficient evidence for a milestone. Require a
     * recent successful fixture response, an actual 1H minute and a short window.
     * Missing timestamps never become proof of fresh data. */
    static boolean checkpointFresh(long now,long fixtureSampledAt,String status,int minute,int mark){
        return isMark(mark) && "1H".equals(status) &&
            minute>=mark && minute<=mark+2 &&
            fixtureSampledAt>0 && fixtureSampledAt<=now+5_000L &&
            now-fixtureSampledAt<=60_000L;
    }

    /** A single card can first appear in team statistics OR event feed.
     * Compare their reconciled totals to the last notified total, not each
     * feed's individual change, to avoid repeat alerts on API propagation lag. */
    static boolean newRedCard(boolean firstCycle,boolean hadPrevious,int previouslyNotified,int nowObserved){
        return !firstCycle && hadPrevious && nowObserved>previouslyNotified;
    }
    static int combinedRedCount(int statsCount,int eventsCount){
        return Math.max(statsCount,eventsCount);
    }
    /** One player cannot receive two distinct send-offs in the same fixture.
     * Provider changes to the minute/description must not double-count it. */
    static String redEventIdentity(int teamId,int playerId,int minute,int extra,int index){
        if(playerId>0)return teamId+":"+playerId;
        // When player identity is absent, preserve separate unknown events.
        if(teamId>0)return teamId+":"+minute+":"+extra;
        return "unknown:"+minute+":"+extra+":"+index;
    }
    private static boolean isMark(int mark){
        for(int m:MARKS)if(m==mark)return true;
        return false;
    }

    /** Downward score corrections (e.g. disallowed goal) are not a new goal. */
    static boolean goalOccurred(boolean firstCycle,boolean hadPrevious,boolean firstHalf,
                                int prevHome,int prevAway,int home,int away){
        return !firstCycle && hadPrevious && firstHalf &&
            (home>prevHome || away>prevAway);
    }
}
