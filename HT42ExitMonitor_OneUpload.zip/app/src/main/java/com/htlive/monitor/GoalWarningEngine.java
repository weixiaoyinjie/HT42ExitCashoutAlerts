package com.htlive.monitor;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Heuristic, conservative pressure observation system. It does NOT calculate a
 * calibrated goal probability or infer unknown live dangerous-attack data.
 * Input is genuine changes of API-FOOTBALL cumulative first-half match stats.
 */
public final class GoalWarningEngine {
    private GoalWarningEngine() {}
    private static final String[] SIDES={"home","away"};

    private static double value(JSONObject j,String field){
        if(j==null || !j.has(field) || j.isNull(field))return Double.NaN;
        return j.optDouble(field,Double.NaN);
    }
    private static boolean valid(double x){return Double.isFinite(x)&&x>=0;}
    private static double rounded(double x){return Math.round(x*100d)/100d;}

    /** Selects a real timestamped sample that is roughly the requested age. */
    private static JSONObject sample(JSONArray history,int minute,long now,int minAge,int maxAge,int target){
        if(history==null)return null;
        JSONObject best=null;int bestScore=Integer.MAX_VALUE;
        for(int i=0;i<history.length();i++){
            JSONObject point=history.optJSONObject(i);if(point==null)continue;
            int age=minute-point.optInt("minute",minute);
            long ms=now-point.optLong("time",0L);
            // Both match clock and observed wall time must support this window.
            if(age<minAge||age>maxAge||ms<minAge*50_000L||ms>maxAge*82_000L)continue;
            JSONObject st=point.optJSONObject("stats");
            if(st==null||!st.optBoolean("available"))continue;
            int score=Math.abs(age-target)*10+(int)Math.abs(ms/60000L-age);
            if(best==null||score<bestScore){best=point;bestScore=score;}
        }
        return best;
    }
    /** Missing / retroactively revised cumulative key stats => no trusted diff. */
    private static JSONObject difference(JSONObject current,JSONObject previous,int minutes)throws Exception{
        if(previous==null)return null;
        JSONObject before=previous.optJSONObject("stats");
        if(current==null||before==null||!before.optBoolean("available"))return null;
        JSONObject result=new JSONObject().put("minutes",minutes);
        for(String side:SIDES){
            JSONObject now=current.optJSONObject(side),old=before.optJSONObject(side);
            if(now==null||old==null)return null;
            JSONObject delta=new JSONObject();
            for(String field:new String[]{"shots","on","box","off","blocked","corners","freeKicks","danger"}){
                double a=value(now,field),b=value(old,field);
                if((field.equals("shots")||field.equals("on")||field.equals("box")) &&
                       (!valid(a)||!valid(b)||a<b))return null;
                delta.put(field, valid(a)&&valid(b)&&a>=b?rounded(a-b):JSONObject.NULL);
            }
            double a=value(now,"xg"),b=value(old,"xg");
            delta.put("xg",valid(a)&&valid(b)&&a>=b?rounded(a-b):JSONObject.NULL);
            result.put(side,delta);
        }
        return result;
    }
    private static JSONObject empty(String level,String rating,String title,String reason,String risk)throws Exception{
        return new JSONObject().put("level",level).put("rating",rating)
            .put("title",title).put("reason",reason).put("risk",risk)
            .put("momentum","尚未确认短窗攻势")
            .put("notify",false).put("side","")
            .put("quality","由真实统计快照的增量计算，非进球概率；非危险进攻逐次事件");
    }
    private static double signal(JSONObject d){
        if(d==null)return 0;
        double s=value(d,"shots"),on=value(d,"on"),box=value(d,"box");
        if(!valid(s)||!valid(on)||!valid(box))return 0;
        double xg=value(d,"xg");
        return .4*s+1.6*on+1.15*box+(valid(xg)?Math.min(xg,1)*2.0:0);
    }
    private static double at(JSONObject stats,String side,String field){
        return value(stats==null?null:stats.optJSONObject(side),field);
    }
    private static boolean up(JSONObject a,JSONObject b,String field){
        double x=value(a,field),y=value(b,field);
        return valid(x)&&valid(y)&&x>y;
    }
    private static boolean oneGoalLead(JSONObject match){
        int h=match.optInt("h",-1),a=match.optInt("a",-1);
        return (h==1&&a==0)||(h==0&&a==1);
    }
    private static String leadingSide(JSONObject match){
        int h=match.optInt("h",-1),a=match.optInt("a",-1);
        return h>a?"home":a>h?"away":"";
    }
    /** Dual-side alert system: early cumulative control, verified short-window pressure,
     *  and NEW pressure after reaching 1-0/0-1. No unmeasured goal probabilities. */
    public static JSONObject analyze(JSONObject match,JSONObject previous,long now)throws Exception{
        int minute=match.optInt("minute",0);
        if(!"1H".equals(match.optString("status")))
            return empty("PASS","PASS","不在上半场","仅在上半场和补时监测攻势。","当前比赛状态不适用");
        if(minute<3)return empty("observe","C级","开赛观察 · 建立基线","3分钟前采样；重大红牌、点球等另行提示。","开场样本很少");
        JSONObject stats=match.optJSONObject("stats");
        if(stats==null||!stats.optBoolean("available")||match.has("dataError"))
            return empty("PASS","PASS","实时统计缺失","需要双方总射门、射正及禁区射门；缺失时不能推断压制。","接口可能延迟或联赛未覆盖");
        if(previous!=null && (match.optInt("h")!=previous.optInt("h")||match.optInt("a")!=previous.optInt("a")))
            return empty("observe","C级","比分已改变 · 重新观察","独立的进球通知已触发；新比分下的射门需重新采样。","进球前的攻势不能作为进球后的证据");
        if(match.optBoolean("newRed") || match.optLong("lastRedAt",0L)>0 && now-match.optLong("lastRedAt")<2*60_000L)
            return empty("observe","C级","红牌 / 人数变化 · 重新观察","已通过独立事件发出红牌提示，之后重新采集当前攻势。","红牌前后战术结构变化，旧趋势不可靠");
        if(match.optLong("lastDisruptionAt",0L)>0 && now-match.optLong("lastDisruptionAt")<60_000L)
            return empty("observe","C级","点球或VAR判罚后复核","关键判罚已独立通知，后续攻势需要重新采样。","不能据关键判罚臆测进球");

        JSONArray hist=match.optJSONArray("history");
        JSONObject p3=sample(hist,minute,now,2,4,3), p5=sample(hist,minute,now,4,7,5), p10=sample(hist,minute,now,8,12,10);
        JSONObject w3=p3==null?null:difference(stats,p3,minute-p3.optInt("minute"));
        JSONObject w5=p5==null?null:difference(stats,p5,minute-p5.optInt("minute"));
        JSONObject w10=p10==null?null:difference(stats,p10,minute-p10.optInt("minute"));
        JSONObject recent=w5!=null?w5:w3;
        JSONObject sh=stats.optJSONObject("home"),sa=stats.optJSONObject("away");
        String chosen="",kind="",level="observe",reason="";
        double best=0;
        // The user's 70/30 possession + 3/1 shots example MUST be considered,
        // even when a complete 5-minute window has not yet been observed.
        for(String side:SIDES){
            String other="home".equals(side)?"away":"home";
            JSONObject s=stats.optJSONObject(side),o=stats.optJSONObject(other);
            double pos=value(s,"pos"),shots=value(s,"shots"),opShots=value(o,"shots");
            double on=value(s,"on"),opOn=value(o,"on");
            double box=value(s,"box"),opBox=value(o,"box");
            double xg=value(s,"xg"),opXg=value(o,"xg");
            boolean threeToOne=valid(pos)&&pos>=68&&valid(shots)&&valid(opShots)&&shots>=3&&shots-opShots>=2;
            boolean reinforced=valid(pos)&&pos>=62&&valid(shots)&&valid(opShots)&&shots>=4&&shots-opShots>=2 &&
               ((valid(on)&&valid(opOn)&&on>opOn)||(valid(box)&&valid(opBox)&&box>opBox));
            boolean shotQuality=valid(shots)&&valid(opShots)&&shots>=4&&shots-opShots>=2 &&
               ((valid(on)&&valid(opOn)&&on>=opOn+2)||(valid(box)&&valid(opBox)&&box>=opBox+2)||
                 (valid(xg)&&valid(opXg)&&xg>=opXg+.3));
            boolean smallQuality=valid(shots)&&valid(opShots)&&shots>=2&&shots>opShots &&
               valid(on)&&valid(opOn)&&on>opOn && valid(box)&&valid(opBox)&&box>opBox;
            if(threeToOne||reinforced||shotQuality||smallQuality){
                double rank=(threeToOne?4:0)+(reinforced?3:0)+(shotQuality?5:0)+(smallQuality?2:0)+
                   (valid(shots)&&valid(opShots)?Math.min(8,shots-opShots):0);
                if(rank>best){
                    best=rank;chosen=side;kind="cumulative";level="watch";
                    String sideName="home".equals(side)?"主队":"客队";
                    reason=sideName+"累计控球 "+(valid(pos)?(int)pos+"%":"—")+"，射门 "+
                        (valid(shots)?(int)shots+"":"—")+" 对 "+(valid(opShots)?(int)opShots+"":"—")+
                        "；射正 "+(valid(on)?(int)on+"":"—")+" 对 "+(valid(opOn)?(int)opOn+"":"—")+
                        "，禁区内射门 "+(valid(box)?(int)box+"":"—")+" 对 "+(valid(opBox)?(int)opBox+"":"—")+
                        "。累计优势先提醒，待最近5分钟及xG确认。";
                }
            }
        }
        if(recent!=null){
            double homeScore=signal(recent.optJSONObject("home")),awayScore=signal(recent.optJSONObject("away"));
            String side=homeScore>=awayScore?"home":"away";
            JSONObject lead=recent.optJSONObject(side),opp=recent.optJSONObject("home".equals(side)?"away":"home");
            double ss=value(lead,"shots"),so=value(lead,"on"),sb=value(lead,"box"),sx=value(lead,"xg");
            double diff=Math.abs(homeScore-awayScore);
            boolean early=valid(ss)&&ss>=2&&diff>=1.5 && ((valid(so)&&so>=1)||(valid(sb)&&sb>=2));
            boolean sustained=valid(ss)&&ss>=3&&valid(so)&&so>=1&&valid(sb)&&sb>=1&&diff>=2.7;
            boolean strong=valid(ss)&&ss>=4&&valid(so)&&so>=2&&valid(sb)&&sb>=2&&diff>=4.0;
            if(early||sustained||strong){
                double rank=strong?14:sustained?10:7;
                if(rank>=best || chosen.isEmpty()){
                    best=rank;chosen=side;kind="recent";level=strong?"strong":"watch";
                    reason=("home".equals(side)?"主队":"客队")+"最近"+recent.optInt("minutes")+
                        "分钟射门+"+(int)ss+"，射正+"+(valid(so)?(int)so:0)+"，禁区内+"+
                        (valid(sb)?(int)sb:0)+"；对方射门+"+(int)Math.max(0,value(opp,"shots"))+"。"+
                        (valid(sx)?"xG新增+"+rounded(sx)+"。":"xG增量未提供。 ");
                }
            }
        }
        // Detect additional attempts AFTER 1-0/0-1; the old pre-goal history
        // has already been cleared and must not be reused.
        if(oneGoalLead(match)){
            String side=leadingSide(match);
            JSONObject current=stats.optJSONObject(side);
            JSONObject former=previous==null?null:previous.optJSONObject("stats")==null?null:previous.optJSONObject("stats").optJSONObject(side);
            boolean sameScore=previous!=null && match.optInt("h")==previous.optInt("h") && match.optInt("a")==previous.optInt("a");
            double shDiff=0,onDiff=0,boxDiff=0;
            if(sameScore && current!=null&&former!=null){
                double sn=value(current,"shots"),sp=value(former,"shots"),a=value(current,"on"),b=value(former,"on"),
                    bx=value(current,"box"),by=value(former,"box");
                shDiff=valid(sn)&&valid(sp)&&sn>=sp?sn-sp:0;
                onDiff=valid(a)&&valid(b)&&a>=b?a-b:0;
                boxDiff=valid(bx)&&valid(by)&&bx>=by?bx-by:0;
            }
            JSONObject rd=recent==null?null:recent.optJSONObject(side);
            boolean afterGoal=(shDiff>=2 || shDiff>=1&&(onDiff>=1||boxDiff>=1||value(current,"pos")>=62)) ||
                (rd!=null && value(rd,"shots")>=2 &&
                 (value(rd,"on")>=1 || value(rd,"box")>=1));
            if(afterGoal && sameScore){
                chosen=side;kind="afterGoal";level="strong";
                reason="比分已是"+match.optInt("h")+"-"+match.optInt("a")+"，领先的"+
                    ("home".equals(side)?"主队":"客队")+"仍继续进攻！本轮新增射门+"+
                    (int)shDiff+"、射正+"+(int)onDiff+"、禁区射门+"+(int)boxDiff+
                    "。下一球可能使1-0/0-1等准确比分单失效，请立即复核当前结算报价。";
            }
        }
        JSONObject out;
        if("observe".equals(level)){
            out=empty("observe","C级","当前未确认明显单边优势",
                "仅有少量或接近的累计统计；继续双向监控控球、射门、射正、禁区和xG。",
                "两队可能迅速交换攻势；尚未取得可操作的优势证据。");
        }else{
            String team="home".equals(chosen)?"主队":"客队";
            String title="afterGoal".equals(kind)?"1-0/0-1后领先方继续压制 · 结算复核":
                "recent".equals(kind)?team+"近几分钟攻势增强 · 结算观察":team+"累计数据占优 · 启动AI复核";
            if(minute>=40)title="40分钟后重点复核 · "+title;
            out=empty(level,"strong".equals(level)?"B级":"C级",title,reason,
                 "控球和射门数量不等于下一球概率；需核对xG质量、攻守变化、数据时效及平台可结算金额。"+
                   (minute>=40?"补时长度不确定，避免把赛程时间当作精准终止时刻。":""));
            out.put("side",chosen).put("kind",kind).put("notify",true);
        }
        out.put("three",w3==null?JSONObject.NULL:w3)
           .put("five",w5==null?JSONObject.NULL:w5)
           .put("ten",w10==null?JSONObject.NULL:w10)
           .put("momentum",recent==null?"短窗样本不足：以当前真实累计数据先预警":
             "已取得近"+recent.optInt("minutes")+"分钟快照，和累计表现交叉判断")
           .put("pressureHome",recent==null?0:rounded(signal(recent.optJSONObject("home"))))
           .put("pressureAway",recent==null?0:rounded(signal(recent.optJSONObject("away"))));
        return out;
    }

    /** Attach independently observed changes to every checkpoint, including PASS and no-alert. */
    public static void attachWindows(JSONObject match,long now)throws Exception{
        JSONObject warning=match.optJSONObject("goalWarning");
        if(warning==null)return;
        JSONObject stats=match.optJSONObject("stats");
        if(stats==null||!stats.optBoolean("available")||match.has("dataError"))return;
        JSONArray history=match.optJSONArray("history");
        int minute=match.optInt("minute",0);
        // Following a goal or red card, history is reset and no pre-event trend is reused.
        int[][] settings={{2,4,3},{4,7,5},{8,12,10}};
        String[] names={"three","five","ten"};
        for(int i=0;i<names.length;i++){
            if(warning.optJSONObject(names[i])!=null)continue;
            int[] r=settings[i];
            JSONObject p=sample(history,minute,now,r[0],r[1],r[2]);
            JSONObject diff=p==null?null:difference(stats,p,minute-p.optInt("minute"));
            if(diff!=null)warning.put(names[i],diff);
        }
    }

    /** One first baseline alert is allowed for the 70/30 + 3/1 case.
     *  Later repeats require new on-field evidence, not just time passing. */
    public static boolean shouldNotify(JSONObject match,JSONObject previous,long now){
        JSONObject w=match.optJSONObject("goalWarning");
        if(w==null||!w.optBoolean("notify")||!"1H".equals(match.optString("status")))return false;
        String side=w.optString("side"),level=w.optString("level"),kind=w.optString("kind");
        if(side.isEmpty())return false;
        long last=previous==null?0:previous.optLong("lastGoalNotifyAt",0L);
        String priorLevel=previous==null?"":previous.optString("lastGoalNotifyLevel","");
        String priorSide=previous==null?"":previous.optString("lastGoalNotifySide","");
        String priorKind=previous==null?"":previous.optString("lastGoalNotifyKind","");
        boolean escalation="strong".equals(level)&&!"strong".equals(priorLevel);
        boolean reversal=!priorSide.isEmpty()&&!priorSide.equals(side);
        boolean newCategory=!priorKind.isEmpty()&&!priorKind.equals(kind);
        long cooldown=match.optInt("minute")>=40?75_000L:
            ("afterGoal".equals(kind)?90_000L:"strong".equals(level)?3*60_000L:4*60_000L);
        if(last>0 && now-last<((escalation||reversal||newCategory)?30_000L:cooldown))return false;
        JSONObject s=match.optJSONObject("stats"),old=previous==null?null:previous.optJSONObject("stats");
        JSONObject cs=s==null?null:s.optJSONObject(side),ps=old==null?null:old.optJSONObject(side);
        if(cs==null)return false;
        if(ps==null)return last==0; // fresh monitoring baseline; don't invent a recent delta
        // A *new* shot, accurate shot, box shot or updated xG is suitable evidence.
        for(String field:new String[]{"shots","on","box","xg"})if(up(cs,ps,field))return true;
        // 70% ball possession crossing with the already observed 3 vs 1 shots
        // is a meaningful new imbalance but not a prediction of the next goal.
        double p=value(cs,"pos"),prevPos=value(ps,"pos"),sh=value(cs,"shots");
        JSONObject opponent=s.optJSONObject("home".equals(side)?"away":"home");
        double opSh=value(opponent,"shots");
        return valid(p)&&valid(prevPos)&&prevPos<68&&p>=68&&
            valid(sh)&&valid(opSh)&&sh>=3&&sh-opSh>=2;
    }
}
