package com.htlive.monitor;

import org.json.JSONObject;

/** Explains risks to one MAIN correct-score pick and one or two insurance picks.
 *  No odds/cash-out quote is fetched, no bet can be settled by this engine.
 *  All claims about recent pressure require observed 5/10 minute sample deltas. */
public final class ScorePlanRiskEngine {
    private ScorePlanRiskEngine(){}
    public static boolean validPick(String s){return s!=null && s.matches("[0-9]-[0-9]");}
    public static JSONObject normalize(JSONObject source)throws Exception{
        JSONObject o=new JSONObject();
        int count=source==null?2:source.optInt("count",2);
        if(count!=3)count=2;
        o.put("count",count);
        for(String k:new String[]{"main","backup1","backup2"}){
            String s=source==null?"":source.optString(k,"").trim().replace('：','-').replace(':','-');
            if(!s.isEmpty()&&!validPick(s))throw new IllegalArgumentException("比分格式需为0-0至9-9");
            o.put(k,k.equals("backup2")&&count==2?"":s);
        }
        return o;
    }
    private static String score(JSONObject o){return o.optInt("h",0)+"-"+o.optInt("a",0);}
    private static int relation(int h,int a,String target){
        if(!validPick(target))return -1;
        int th=target.charAt(0)-'0',ta=target.charAt(2)-'0';
        if(h>th||a>ta)return 2; // irrevocably passed the correct score
        if(h==th&&a==ta)return 1;
        return 0; // still reachable
    }
    private static double number(JSONObject x,String field){
        if(x==null || x.isNull(field))return Double.NaN;
        double d=x.optDouble(field,Double.NaN);
        return Double.isFinite(d)&&d>=0?d:Double.NaN;
    }
    private static boolean known(double d){return Double.isFinite(d);}
    private static String fmt(double d){return known(d)?String.valueOf(Math.round(d*100d)/100d):"—";}
    private static String stat(JSONObject stats,String key){
        return fmt(number(stats==null?null:stats.optJSONObject("home"),key))+"/"+
               fmt(number(stats==null?null:stats.optJSONObject("away"),key));
    }
    private static String pressure(JSONObject window){
        if(window==null || window.optInt("minutes",0)<3)return "";
        JSONObject h=window.optJSONObject("home"),a=window.optJSONObject("away");
        String winner="";double biggest=0;
        for(String side:new String[]{"home","away"}){
            JSONObject l="home".equals(side)?h:a,opp="home".equals(side)?a:h;
            double shots=number(l,"shots"), otherShots=number(opp,"shots");
            double on=number(l,"on"), box=number(l,"box"),xg=number(l,"xg");
            // Recent dominance requires both volume AND an independent chance-quality clue.
            boolean quantity=known(shots)&&shots>=2 && (!known(otherShots)||shots>=otherShots+1);
            boolean quality=(known(on)&&on>=1)||(known(box)&&box>=1)||(known(xg)&&xg>=.12);
            if(!quantity||!quality)continue;
            double strength=shots+(known(on)?on*1.4:0)+(known(box)?box*.7:0)+(known(xg)?xg*3:0)
                    -(known(otherShots)?otherShots*.8:0);
            if(strength>biggest){winner=side;biggest=strength;}
        }
        if(winner.isEmpty())return "";
        JSONObject v="home".equals(winner)?h:a;
        return ("home".equals(winner)?"主队":"客队")+"最近"+window.optInt("minutes")+
            "分钟新增射门"+fmt(number(v,"shots"))+"、射正"+fmt(number(v,"on"))+
            "、禁区射门"+fmt(number(v,"box"))+"、xG"+fmt(number(v,"xg"));
    }
    private static JSONObject result(String kind,String grade,String title,String explanation,boolean notify,
                                     String state,String plan)throws Exception{
        return new JSONObject().put("kind",kind).put("rating",grade).put("title",title)
            .put("reason",explanation).put("notify",notify).put("state",state)
            .put("plan",plan).put("action",notify?"打开下注App核对可用结算价":"继续观察")
            .put("disclaimer","不掌握各单投注额、投注赔率、平台实时结算金额；无自动结算或保本保证。");
    }
    public static JSONObject analyze(JSONObject match,JSONObject plan,long now)throws Exception{
        JSONObject p=normalize(plan);
        String main=p.optString("main"),b1=p.optString("backup1"),b2=p.optString("backup2");
        String joined="主单"+(main.isEmpty()?"未填":main)+"，保险1 "+(b1.isEmpty()?"未填":b1)+
            (p.optInt("count")==3?"，保险2 "+(b2.isEmpty()?"未填":b2):"");
        if(!"1H".equals(match.optString("status")))
            return result("inactive","PASS","尚未进入上半场","等待真实比赛进程；不要按开赛预估时间冒充比赛分钟。",false,"",joined);
        int h=match.optInt("h",-1),a=match.optInt("a",-1),minute=match.optInt("minute",0);
        if(h<0||a<0)return result("missing","PASS","比分未验证","足球 API 尚未提供可信当前比分。",false,"",joined);
        String current=h+"-"+a;
        if(main.isEmpty())return result("unconfigured","PASS","请填写主单及保险单比分",
            minute+"′ "+current+"；未填主单，无法针对持仓判断结单风险。",false,"",joined);
        int mr=relation(h,a,main),r1=relation(h,a,b1),r2=relation(h,a,b2);
        int alive=(mr==0||mr==1?1:0)+(r1==0||r1==1?1:0)+(r2==0||r2==1?1:0);
        String backupStatus="保险1 "+(b1.isEmpty()?"未填":b1+"（"+(r1==2?"已超出":r1==1?"当前命中":"仍有可能")+"）")+
            (p.optInt("count")==3?"；保险2 "+(b2.isEmpty()?"未填":b2+"（"+(r2==2?"已超出":r2==1?"当前命中":"仍有可能")+"）"):"");
        if(mr==2){
            String state=alive==0?"全部已超出":"主单已超出，尚有其他可能";
            return result("main-broken","B级","主单"+main+"已超出 · 核对全部注单",
                "当前"+current+"，主单"+main+"无法在本半场恢复；"+backupStatus+"。"+
                (alive==0?"已填写比分全部失去命中可能。":"其他注单不能因此视为保本。"),false,state,joined);
        }
        boolean statsFresh=match.optJSONObject("stats")!=null &&
             match.optJSONObject("stats").optBoolean("available") &&
             match.optLong("lastStatsAt",0L)>0 && now-match.optLong("lastStatsAt",0L)<=90_000L &&
             !match.has("dataError");
        JSONObject stats=statsFresh?match.optJSONObject("stats"):null;
        JSONObject gw=match.optJSONObject("goalWarning");
        JSONObject five=gw==null?null:gw.optJSONObject("five");
        JSONObject ten=gw==null?null:gw.optJSONObject("ten");
        String recently=statsFresh?pressure(five):"";
        if(recently.isEmpty() && statsFresh)recently=pressure(ten);
        if(mr==1){
            if(!recently.isEmpty())return result("hit-pressure","B级","主单"+main+"当前命中 · 新攻势威胁",
                "当前"+current+"符合主单；"+recently+"。再进球将破坏主单准确比分；"+backupStatus+"。",true,"命中且出现新增压力",joined);
            if(minute>=30)return result("hit-clock","C级","主单"+main+"当前命中 · 时间风险",
                "第"+minute+"分钟为"+current+"，距离42分钟人工结单节点已近；"+backupStatus+"。"+
                (statsFresh?"未确认最近5～10分钟持续攻势。":"缺少可信最近统计，不能判断攻势。"),false,"当前命中",joined);
            return result("hit-observe","C级","主单"+main+"目前命中 · 继续复核",
                "当前"+current+"符合主单；一次进球就可能改变结果。"+backupStatus+"。",false,"当前命中",joined);
        }
        // Low-event 0-0 is incompatible with a main pick needing one or more goals.
        if(minute>=28 && h==0 && a==0 && statsFresh){
            JSONObject sh=stats.optJSONObject("home"),sa=stats.optJSONObject("away");
            double hx=number(sh,"xg"),ax=number(sa,"xg"),hs=number(sh,"shots"),as=number(sa,"shots");
            double hon=number(sh,"on"),aon=number(sa,"on"),hb=number(sh,"box"),ab=number(sa,"box");
            boolean quiet=known(hx)&&known(ax)&&hx<=.2&&ax<=.2 &&
                known(hs)&&known(as)&&hs+as<=6 &&known(hon)&&known(aon)&&hon+aon<=1 &&
                known(hb)&&known(ab)&&hb+ab<=3;
            if(quiet)return result("missing-quiet","C级","主单"+main+"未实现 · 进攻沉闷",
                "第"+minute+"分钟仍0-0；累计xG "+stat(stats,"xg")+"、射门 "+stat(stats,"shots")+
                "、射正 "+stat(stats,"on")+"，有效机会偏少。主单还需要进球；"+backupStatus+"。",true,"未到位且沉闷",joined);
        }
        if(!recently.isEmpty())return result("open-pressure","C级","主单"+main+"尚未实现 · 攻势正在变化",
             "当前"+current+"仍未到主单目标；"+recently+"。注意进攻方与主单/保险单方向是否一致；"+backupStatus+"。",
             minute>=15,"未到位且攻势增强",joined);
        return result("open-observe","PASS","主单"+main+"尚未实现 · 等待确认",
             "第"+minute+"分钟"+current+"；"+backupStatus+"。"+(statsFresh?
             "无足够的最近5～10分钟增量证明单边压制。":"实时统计缺失或过期，仅能核对比分。"),
             false,"未到位",joined);
    }
    /** Avoid a flood of notifications; checkpoints and goals have their own channels. */
    public static boolean shouldNotify(JSONObject current,JSONObject previous,long now){
        if(!"1H".equals(current.optString("status")))return false;
        int minute=current.optInt("minute",0);
        if(minute<16 || minute>=42)return false;
        JSONObject risk=current.optJSONObject("scorePlanRisk");
        if(risk==null||!risk.optBoolean("notify"))return false;
        if(previous!=null && previous.optInt("minute",0)==minute &&
            previous.optString("h").equals(current.optString("h")) &&
            previous.optString("a").equals(current.optString("a")) &&
            now-previous.optLong("lastScorePlanAlertAt",0L)<180_000L)return false;
        long last=previous==null?0:previous.optLong("lastScorePlanAlertAt",0L);
        if(last>0 && now-last<180_000L)return false;
        String kind=risk.optString("kind");
        JSONObject old=previous==null?null:previous.optJSONObject("scorePlanRisk");
        boolean changed=old==null || !kind.equals(old.optString("kind")) ||
            !current.optString("mainPick").equals(previous.optString("mainPick"));
        // Repeating an unchanged danger assessment every three minutes is noise.
        return changed;
    }
}
