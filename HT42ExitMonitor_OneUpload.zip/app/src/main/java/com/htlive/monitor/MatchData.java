package com.htlive.monitor;

import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** Shared statistics parser and conservative notification formatter. Null is unknown, never zero. */
public final class MatchData {
    private MatchData(){}
    static Object raw(JSONObject team,String type){
        JSONArray stats=team==null?null:team.optJSONArray("statistics");
        if(stats==null)return null;
        for(int i=0;i<stats.length();i++){
            JSONObject s=stats.optJSONObject(i);
            if(s==null||!type.equalsIgnoreCase(s.optString("type")))continue;
            Object v=s.opt("value");
            if(v instanceof JSONObject){JSONObject obj=(JSONObject)v;v=obj.opt("total");if(v==null||v==JSONObject.NULL)v=obj.opt("first");}
            if(v==null||v==JSONObject.NULL||String.valueOf(v).trim().isEmpty())return null;
            return v;
        }
        return null;
    }
    static Number num(JSONObject team,String type,boolean decimal){
        try {Object v=raw(team,type); if(v==null)return null;
            double d=Double.parseDouble(String.valueOf(v).replace("%","").trim());
            if(d<0||!Double.isFinite(d))return null;
            if(decimal)return Double.valueOf(Math.round(d*100.0)/100.0);
            return Integer.valueOf((int)Math.round(d));
        }catch(Exception e){return null;}
    }
    static JSONObject side(JSONObject team)throws Exception {
        JSONObject j=new JSONObject();
        put(j,"shots",num(team,"Total Shots",false));
        put(j,"on",num(team,"Shots on Goal",false));
        put(j,"off",num(team,"Shots off Goal",false));
        put(j,"blocked",num(team,"Blocked Shots",false));
        put(j,"box",num(team,"Shots insidebox",false));
        put(j,"outside",num(team,"Shots outsidebox",false));
        put(j,"pos",num(team,"Ball Possession",false));
        put(j,"corners",num(team,"Corner Kicks",false));
        put(j,"freeKicks",num(team,"Free Kicks",false));
        put(j,"fouls",num(team,"Fouls",false));
        put(j,"yellow",num(team,"Yellow Cards",false));
        put(j,"red",num(team,"Red Cards",false));
        Number danger=num(team,"Dangerous Attacks",false);
        if(danger==null)danger=num(team,"Dangerous attacks",false);
        put(j,"danger",danger);
        Number xg=num(team,"expected_goals",true);
        if(xg==null)xg=num(team,"Expected Goals",true);
        if(xg==null)xg=num(team,"Expected goals",true);
        put(j,"xg",xg);
        return j;
    }
    private static void put(JSONObject j,String k,Number v)throws Exception{j.put(k,v==null?JSONObject.NULL:v);}
    static JSONObject combine(JSONArray array,int homeId,int awayId)throws Exception{
        JSONObject a=null,b=null;
        if(array!=null)for(int i=0;i<array.length();i++){
            JSONObject t=array.optJSONObject(i);if(t==null)continue;
            int team=t.optJSONObject("team")==null?0:t.optJSONObject("team").optInt("id");
            if(team==homeId)a=t;else if(team==awayId)b=t;
        }
        JSONObject out=new JSONObject();
        out.put("home",side(a));out.put("away",side(b));
        out.put("available",a!=null&&b!=null&&a.has("statistics")&&b.has("statistics") &&
            raw(a,"Total Shots")!=null && raw(b,"Total Shots")!=null &&
            raw(a,"Shots on Goal")!=null && raw(b,"Shots on Goal")!=null &&
            raw(a,"Shots insidebox")!=null && raw(b,"Shots insidebox")!=null);
        return out;
    }
    static JSONObject parseFixture(JSONObject fixture,JSONObject stats) throws Exception {
        JSONObject f=fixture.optJSONObject("fixture"),status=f==null?null:f.optJSONObject("status");
        JSONObject teams=fixture.optJSONObject("teams"),home=teams==null?null:teams.optJSONObject("home"),away=teams==null?null:teams.optJSONObject("away");
        JSONObject goals=fixture.optJSONObject("goals");
        JSONObject out=new JSONObject();
        out.put("id",f==null?"":String.valueOf(f.optInt("id")));
        out.put("home",home==null?"主队":home.optString("name"));
        out.put("away",away==null?"客队":away.optString("name"));
        out.put("minute",status==null?0:status.optInt("elapsed",0));
        out.put("status",status==null?"?":status.optString("short","?"));
        out.put("h",goals==null||goals.isNull("home")?"?":goals.opt("home"));
        out.put("a",goals==null||goals.isNull("away")?"?":goals.opt("away"));
        if(stats!=null)out.put("stats",stats);
        return out;
    }
    private static String cell(JSONObject o,String k){
        if(o==null||o.isNull(k)||!o.has(k))return "—";
        String s=o.optString(k,"—");return s.isEmpty()?"—":s;
    }
    private static String compare(JSONObject x,String k){
        JSONObject st=x.optJSONObject("stats");JSONObject h=st==null?null:st.optJSONObject("home"),a=st==null?null:st.optJSONObject("away");
        return cell(h,k)+" / "+cell(a,k);
    }
    private static String dcompare(JSONObject x,String k){
        JSONObject d=x.optJSONObject("delta"),h=d==null?null:d.optJSONObject("home"),a=d==null?null:d.optJSONObject("away");
        return cell(h,k)+" / "+cell(a,k);
    }
    static String stamp(long millis){
        if(millis<=0)return "未记录";
        SimpleDateFormat df=new SimpleDateFormat("MM-dd HH:mm:ss",Locale.CHINA);
        df.setTimeZone(TimeZone.getTimeZone("America/Argentina/Buenos_Aires"));
        return df.format(new Date(millis))+"（阿根廷）";
    }
    static String detail(JSONObject x,long retrievedAt,String origin){
        if(x==null)return "目前没有该场比赛数据。请检查网络、API Key 和监控状态。";
        StringBuilder b=new StringBuilder();
        b.append(x.optString("home","主队")).append("  VS  ").append(x.optString("away","客队")).append('\n');
        b.append("上半场 ").append(x.optInt("minute",0)).append("′ · 状态 ").append(x.optString("status","?"));
        b.append("\n比分  ").append(x.optString("h","?")).append(" : ").append(x.optString("a","?"));
        if(x.has("mainPick"))b.append("\n我的主单准确比分  ").append(x.optString("mainPick"));
        JSONObject planRisk=x.optJSONObject("scorePlanRisk");
        if(planRisk!=null){
            b.append("\n\n─── 主单 + 保险单结单复核 ───");
            b.append("\n比分组合：").append(planRisk.optString("plan"));
            b.append("\n评级：").append(planRisk.optString("rating"));
            b.append("\n提醒：").append(planRisk.optString("title"));
            b.append("\n数据证据：").append(planRisk.optString("reason"));
            b.append("\n未获取投注平台实际提前结算价，不能自动成交或保证保本。");
        }
        JSONObject pickRisk=x.optJSONObject("mainPickRisk");
        if(pickRisk!=null && pickRisk.optBoolean("notify")){
            b.append("\n主单预判  ").append(pickRisk.optString("title"));
            b.append("\n数据证据  ").append(pickRisk.optString("reason"));
        }
        long age=retrievedAt>0?(System.currentTimeMillis()-retrievedAt):Long.MAX_VALUE;
        b.append("\n数据时间  ").append(stamp(retrievedAt));
        if(age>180_000L)b.append(" ⚠ 已超过3分钟，可能过时");
        if(!origin.isEmpty())b.append("\n来源  ").append(origin);
        b.append("\n\n─── 双方统计（主 / 客） ───");
        b.append("\nxG                 ").append(compare(x,"xg"));
        b.append("\n总射门              ").append(compare(x,"shots"));
        b.append("\n射正                 ").append(compare(x,"on"));
        b.append("\n射偏                 ").append(compare(x,"off"));
        b.append("\n封堵                 ").append(compare(x,"blocked"));
        b.append("\n禁区内射门          ").append(compare(x,"box"));
        b.append("\n禁区外射门          ").append(compare(x,"outside"));
        b.append("\n控球率(%)          ").append(compare(x,"pos"));
        b.append("\n角球                 ").append(compare(x,"corners"));
        b.append("\n任意球(仅接口提供)  ").append(compare(x,"freeKicks"));
        b.append("\n犯规                 ").append(compare(x,"fouls"));
        b.append("\n黄牌                 ").append(compare(x,"yellow"));
        b.append("\n红牌                 ").append(compare(x,"red"));
        b.append("\n危险进攻(若提供)      ").append(compare(x,"danger"));
        b.append("\n\n─── 最近5～10分钟变化 ───");
        b.append("\n走势 ").append(x.optString("trend","未形成有效样本"));
        b.append("\n新增射门       ").append(dcompare(x,"shots"));
        b.append("\n新增射正       ").append(dcompare(x,"on"));
        b.append("\n新增禁区射门  ").append(dcompare(x,"box"));
        b.append("\n新增危险进攻  ").append(dcompare(x,"danger"));
        JSONObject historyWarning=x.optJSONObject("goalWarning");
        if(historyWarning!=null){
            for(String window:new String[]{"three","five","ten"}){
                JSONObject d=historyWarning.optJSONObject(window);
                if(d==null)continue;
                JSONObject dh=d.optJSONObject("home"),da=d.optJSONObject("away");
                b.append("\n近").append(d.optInt("minutes")).append("分钟射门+ ")
                    .append(cell(dh,"shots")).append(" / ").append(cell(da,"shots"));
                b.append("，射正+ ").append(cell(dh,"on")).append(" / ").append(cell(da,"on"));
                b.append("，禁区内+ ").append(cell(dh,"box")).append(" / ").append(cell(da,"box"));
                b.append("，xG+ ").append(cell(dh,"xg")).append(" / ").append(cell(da,"xg"));
                b.append("，角球+ ").append(cell(dh,"corners")).append(" / ").append(cell(da,"corners"));
                b.append("，任意球+ ").append(cell(dh,"freeKicks")).append(" / ").append(cell(da,"freeKicks"));
                b.append("，危险进攻+ ").append(cell(dh,"danger")).append(" / ").append(cell(da,"danger"));
            }
        }
        long statsAt=x.optLong("lastStatsAt",0L);
        if(statsAt>0){
            b.append("\n统计采样于 ").append(stamp(statsAt));
            if(System.currentTimeMillis()-statsAt>90_000L)
                b.append(" ⚠ 超过90秒未刷新，不能作为实时结算依据");
        }
        JSONObject warning=x.optJSONObject("goalWarning");
        b.append("\n\n─── 进球风险预警（非概率） ───");
        if(warning==null)b.append("\n尚未获得可靠的实时预警样本");
        else {
            b.append("\n评级  ").append(warning.optString("rating","PASS"));
            b.append("\n结论  ").append(warning.optString("title","观察"));
            b.append("\n最近变化  ").append(warning.optString("reason","样本不足"));
            b.append("\n10分钟确认  ").append(warning.optString("momentum","暂缺"));
            JSONObject fast=warning.optJSONObject("three");
            if(fast!=null){JSONObject fh=fast.optJSONObject("home"),fa=fast.optJSONObject("away");
                b.append("\n近3分钟射门新增（主/客）  ").append(cell(fh,"shots")).append(" / ").append(cell(fa,"shots"));
            }
            b.append("\n最大风险  ").append(warning.optString("risk","数据不完整"));
        }
        JSONObject ai=x.optJSONObject("aiReview");
        b.append("\n\n─── AI辅助复核（非概率） ───");
        if(ai==null) b.append("\n").append(x.optString("aiReviewError","未启用或未达到调用条件"));
        else{
            b.append("\n结论：").append(ai.optString("conclusion",""));
            b.append("\n风险：").append(ai.optString("risk",""));
            b.append("\nAI建议动作：").append(ai.optString("action","数据不足"));
            b.append("\n时间：").append(stamp(ai.optLong("time",0L)));
            if(System.currentTimeMillis()-ai.optLong("time",0L)>3*60_000L)
                b.append("（可能已过时）");
        }
        b.append("\n\n─── 结算复核 ───\n");
        JSONObject stats=x.optJSONObject("stats");
        boolean available=stats!=null&&stats.optBoolean("available",false);
        if(!"1H".equals(x.optString("status")))b.append("PASS / 当前非上半场；先核对真实开赛时间。\n");
        else if(!available)b.append("PASS / 射门数据不足，不能判断比赛强弱。\n");
        else if(age>180_000L)b.append("暂不判断 / 数据已经过时，先刷新。\n");
        else if(x.optString("trend","").contains("压制"))b.append("重点观察 / 最近压制可能增加后续进球风险。\n");
        else b.append("继续观察 / 尚未形成可以独立支持结算的优势。\n");
        b.append("最大风险：xG、射门质量和场面可能不一致；未获取平台实时结算金额、赔率及全部下注方向。\n");
        b.append("请同时核对你的下注截图、当前结算价和剩余时间。没有足够优势，可以选择不操作。\n");
        if(x.optString("dataError","").length()>0)b.append("\n接口异常：").append(x.optString("dataError"));
        return b.toString();
    }
    /** Notifications prioritize a time-stamped summary and real 5/10-minute deltas. */
    static String notificationBody(JSONObject x,long receivedAt){
        if(x==null)return "没有可用赛况，提醒按预定时间触发，切勿当作实时判断";
        StringBuilder b=new StringBuilder();
        b.append(x.optInt("minute",0)).append("′ ").append(x.optString("h","?"))
         .append("-").append(x.optString("a","?"));
        JSONObject w=x.optJSONObject("goalWarning");
        b.append(" · ").append(w==null?"观察中":w.optString("rating","PASS"));
        JSONObject srp=x.optJSONObject("scorePlanRisk");
        if(srp!=null){
            b.append("\n🎟 组合：").append(srp.optString("plan",""));
            b.append("\n⚠ 组合结单风险：").append(srp.optString("title",""));
            b.append("\n证据：").append(srp.optString("reason",""));
            b.append("\n提醒仅供打开投注平台查看：并不自动结算、不保证保本。");
        }
        JSONObject pr=x.optJSONObject("mainPickRisk");
        if(x.has("mainPick"))b.append(" · 主单").append(x.optString("mainPick"));
        if(pr!=null && pr.optBoolean("notify"))b.append(" · ").append(pr.optString("title"));
        if(pr!=null && pr.optBoolean("notify"))b.append("\n🎯 主单证据：").append(pr.optString("reason",""));
        b.append("\n当前xG ").append(compare(x,"xg"))
         .append(" | 射门 ").append(compare(x,"shots"))
         .append(" | 射正 ").append(compare(x,"on"));
        b.append("\n禁区射门 ").append(compare(x,"box"))
         .append(" | 控球% ").append(compare(x,"pos"))
         .append(" | 角球 ").append(compare(x,"corners"))
         .append(" | 任意球 ").append(compare(x,"freeKicks"))
         .append(" | 危险进攻 ").append(compare(x,"danger"));
        if(w==null)b.append("\n近5/10分钟：暂无完整历史快照，不计算虚构增量");
        if(w!=null)for(String name:new String[]{"five","ten"}){
            JSONObject d=w.optJSONObject(name);
            if(d==null){b.append("\n近").append(name.equals("five")?"5":"10").append("分钟：有效快照不足");continue;}
            JSONObject h=d.optJSONObject("home"),a=d.optJSONObject("away");
            b.append("\n近").append(d.optInt("minutes")).append("分钟增量(主/客)：")
             .append("xG+").append(cell(h,"xg")).append("/").append(cell(a,"xg"))
             .append(" 射门+").append(cell(h,"shots")).append("/").append(cell(a,"shots"))
             .append(" 射正+").append(cell(h,"on")).append("/").append(cell(a,"on"))
             .append(" 禁区+").append(cell(h,"box")).append("/").append(cell(a,"box"))
             .append(" 角球+").append(cell(h,"corners")).append("/").append(cell(a,"corners"))
             .append(" 任意球+").append(cell(h,"freeKicks")).append("/").append(cell(a,"freeKicks"))
             .append(" 危险进攻+").append(cell(h,"danger")).append("/").append(cell(a,"danger"));
        }
        long statsAt=x.optLong("lastStatsAt",0L);
        long changedAt=x.optLong("lastStatsChangedAt",0L);
        if(changedAt>0 && receivedAt-changedAt>=5*60_000L)
            b.append("\n近").append((receivedAt-changedAt)/60_000L)
             .append("分钟统计累计值未变化（可能无机会，也可能接口延迟）");
        if(statsAt<=0)b.append("\n⚠ 未取得可靠统计采样时间");
        else{
            b.append("\n统计采集 ").append(stamp(statsAt));
            if(System.currentTimeMillis()-statsAt>90_000L)b.append(" ⚠ 数据超90秒，不作为实时信号");
        }
        b.append("\n趋势：").append(x.optString("trend","样本不足"));
        if(w!=null){b.append("\n风险：").append(w.optString("title","观察中"));
            b.append("\n证据：").append(w.optString("reason","未形成有效样本"));}
        JSONObject ai=x.optJSONObject("aiReview");
        if(ai!=null){
            long reviewAt=ai.optLong("time",0L);
            b.append("\nAI复核：").append(ai.optString("conclusion",""));
            if(reviewAt<=0||System.currentTimeMillis()-reviewAt>180_000L)b.append("（历史结论，需复核）");
            if(!ai.optString("risk","").isEmpty())b.append("\nAI风险：").append(ai.optString("risk"));
            b.append("\nAI动作：").append(ai.optString("action","数据不足"));
        }else b.append("\nAI复核：未调用/未返回，按足球API规则提示");
        if(x.optInt("minute",0)>=42)b.append("\n⏰ 42分钟退出规则：立即打开下注App查看并人工确认各张单结算。");
        b.append("\n危险进攻仅显示接口真实字段，—表示未提供；不能拿禁区射门冒充危险进攻");
        return b.toString();
    }
    static String shortSummary(JSONObject x,long at){
        if(x==null)return "暂无赛况，点击展开查看数据缺失原因";
        JSONObject w=x.optJSONObject("goalWarning");
        String rating=w==null?"PASS":w.optString("rating","PASS");
        JSONObject pr=x.optJSONObject("mainPickRisk");
        if(pr!=null && pr.optBoolean("notify"))rating=pr.optString("rating",rating);
        String s=x.optInt("minute",0)+"′ "+x.optString("h","?")+"-"+x.optString("a","?")+" "+rating
            +" | xG "+compare(x,"xg")+" | 射门 "+compare(x,"shots")
            +" | 射正 "+compare(x,"on")+" | 控球 "+compare(x,"pos");
        if(x.has("mainPick"))s="主单"+x.optString("mainPick")+" | "+s;
        if(x.optInt("minute",0)>=42)s="⏰ 42分钟结单复核 · "+s;
        long statsAt=x.optLong("lastStatsAt",0L);
        if(statsAt<=0||System.currentTimeMillis()-statsAt>90_000L)s+=" · ⚠统计缺失或过时";
        return s;
    }
}
