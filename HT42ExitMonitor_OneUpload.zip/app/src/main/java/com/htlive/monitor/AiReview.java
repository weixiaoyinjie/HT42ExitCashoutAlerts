package com.htlive.monitor;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Optional second opinion; never predicts a numerical goal probability or triggers alone. */
public final class AiReview {
    private AiReview(){}
    static JSONObject review(JSONObject match,String apiKey) throws Exception {
        if(apiKey==null||apiKey.isEmpty())throw new Exception("未设置AI Key");
        JSONObject slim=new JSONObject();
        for(String s:new String[]{"id","status","minute","h","a","trend","newRed","lastRedAt","mainPick","scorePlan"})
            if(match.has(s))slim.put(s,match.get(s));
        for(String s:new String[]{"stats","delta","goalWarning","mainPickRisk","scorePlanRisk"})
            if(match.has(s))slim.put(s,match.get(s));
        JSONObject req=new JSONObject();
        req.put("model","gpt-4.1-mini");req.put("max_output_tokens",400);
        req.put("instructions","你是实时足球上半场的准确比分组合提前结算复核器，不是预测必中。scorePlan包含用户输入的主单、保险1和可选保险2；scorePlanRisk是规则引擎输出，必须分别讨论每个比分的命中、仍可能命中、已超出状态。目标是15分钟和30分钟判断变化，42分钟默认提醒用户手动检查所有注单的实际结算价，不代表已成交。mainPick是用户主队-客队上半场准确比分；mainPickRisk由真实API数据规则触发，必须复核其证据、时效及是否与当前比分相符。特别针对主单1-0：若场上恰为1-0，任一方下一球都会破坏准确比分；若xG为0.07/0.37、射正0/2、禁区2/3、控球37/63，即使双方射门同为5，也应提示客队威胁；若仍0-0且双方xG很低、射门沉闷，说明1-0需要的进球尚未出现。当控球70/30且射门3/1时，即使没有完整近5分钟窗口也可提示双向数据占优，但不是下一球概率。重点评估goalWarning.five/ten以及最近3/5/10分钟真实增量、比分变化、红牌、点球、定位球增加、比赛分钟和剩余时间。区分总量与进球后的新增攻势：未看到进球后独立快照不得声称继续压制。任何缺失null均为未知；不臆造危险进攻、定位球位置、赔率、结算金额或量化进球概率。只根据可见证据输出JSON包含conclusion、risk、confidence、action四个字符串：action只能是‘复核结算报价’、‘继续观察’或‘数据不足’，此处不代替用户选择也不自动结单；confidence只能是‘数据支持’或‘数据不足’。简洁中文，最多150字。若没有主单，仅作客观双向攻势判断，不应冒称知道用户下注。AI意见仅供参考。\n");
        req.put("input","请二次核对API-FOOTBALL半场快照（未知为null）："+slim.toString());
        req.put("text",new JSONObject().put("format",new JSONObject().put("type","json_object")));
        HttpURLConnection con=(HttpURLConnection)new URL("https://api.openai.com/v1/responses").openConnection();
        try{
            con.setRequestMethod("POST");con.setDoOutput(true);
            con.setConnectTimeout(6500);con.setReadTimeout(9000);
            con.setRequestProperty("Authorization","Bearer "+apiKey);
            con.setRequestProperty("Content-Type","application/json; charset=utf-8");
            try(OutputStream out=con.getOutputStream()){out.write(req.toString().getBytes(StandardCharsets.UTF_8));}
            int status=con.getResponseCode();
            if(status<200||status>=300)throw new Exception("OpenAI HTTP "+status);
            byte[] buf=new byte[4096];int n;ByteArrayOutputStream bytes=new ByteArrayOutputStream();
            try(InputStream in=con.getInputStream()){
                while((n=in.read(buf))!=-1){bytes.write(buf,0,n);if(bytes.size()>250_000)throw new Exception("AI响应超过限制");}
            }
            JSONObject root=new JSONObject(bytes.toString("UTF-8"));
            JSONArray output=root.optJSONArray("output");String text="";
            if(output!=null)for(int i=0;i<output.length();i++){
                JSONObject item=output.optJSONObject(i);if(item==null)continue;
                JSONArray contents=item.optJSONArray("content");if(contents==null)continue;
                for(int k=0;k<contents.length();k++){
                    JSONObject block=contents.optJSONObject(k);
                    if(block!=null&&"output_text".equals(block.optString("type"))){text=block.optString("text");break;}
                }
                if(!text.isEmpty())break;
            }
            JSONObject result=new JSONObject(text);
            return new JSONObject().put("conclusion",truncate(result.optString("conclusion","AI未给出结论"),130))
              .put("risk",truncate(result.optString("risk",""),120))
              .put("confidence",truncate(result.optString("confidence","数据不足"),16))
              .put("action",parseAction(result.optString("action","继续观察")))
              .put("time",System.currentTimeMillis());
        }finally{con.disconnect();}
    }
    private static String parseAction(String value){
        if("复核结算报价".equals(value)||"继续观察".equals(value)||"数据不足".equals(value))return value;
        return "数据不足";
    }
    private static String truncate(String s,int size){return s.length()>size?s.substring(0,size):s;}
}
