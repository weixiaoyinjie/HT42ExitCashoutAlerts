package com.htlive.monitor;
import org.json.JSONObject;
public class ScorePlanRiskEngineTest {
  static void check(boolean yes,String reason){if(!yes)throw new AssertionError(reason);}
  static JSONObject plan(int count,String main,String b1,String b2)throws Exception{
    return new JSONObject().put("count",count).put("main",main).put("backup1",b1).put("backup2",b2);
  }
  static JSONObject match(int min,int h,int a,long now)throws Exception{
    return new JSONObject().put("status","1H").put("minute",min).put("h",h).put("a",a).put("lastStatsAt",now);
  }
  static JSONObject side(double xg,int shots,int on,int box)throws Exception{
    return new JSONObject().put("xg",xg).put("shots",shots).put("on",on).put("box",box);
  }
  public static void main(String[] args)throws Exception{
    long now=1000000L;
    JSONObject p=plan(2,"1-0","0-0","2-0");
    check(ScorePlanRiskEngine.normalize(p).optString("backup2").isEmpty(),"two-pick mode masks third");
    JSONObject no=ScorePlanRiskEngine.analyze(match(30,1,0,now),p,now);
    check("hit-clock".equals(no.optString("kind")),"exact score with no stats = time risk, no invented pressure");
    check(!no.optBoolean("notify"),"no fake pressure alert");
    JSONObject broken=ScorePlanRiskEngine.analyze(match(24,2,1,now),p,now);
    check("main-broken".equals(broken.optString("kind")),"irrecoverable score known from scoreboard");
    JSONObject calm=match(30,0,0,now).put("stats",new JSONObject().put("available",true)
       .put("home",side(.05,2,0,1)).put("away",side(.08,2,0,1)));
    JSONObject quiet=ScorePlanRiskEngine.analyze(calm,p,now);
    check("missing-quiet".equals(quiet.optString("kind")),"0-0 no chance with 1-0 main warns");
    check(quiet.optBoolean("notify"),"quiet warning prompts quote check");
    JSONObject active=match(31,1,0,now).put("stats",new JSONObject().put("available",true)
       .put("home",side(.50,8,3,4)).put("away",side(.15,3,1,1)));
    JSONObject five=new JSONObject().put("minutes",5).put("home",side(.25,3,2,2)).put("away",side(.01,0,0,0));
    active.put("goalWarning",new JSONObject().put("five",five));
    JSONObject threat=ScorePlanRiskEngine.analyze(active,plan(3,"1-0","0-0","2-0"),now);
    check("hit-pressure".equals(threat.optString("kind")),"valid window after 1-0 shows real new pressure");
    check(threat.optString("reason").contains("保险2 2-0"),"third option included");
    check(ScorePlanRiskEngine.shouldNotify(active.put("scorePlanRisk",threat),null,now),"first risk alert 31'");
    check(!ScorePlanRiskEngine.shouldNotify(active.put("minute",42),null,now),"no generic risk alert 42'");
    JSONObject stale=match(36,1,0,now-110000).put("stats",active.optJSONObject("stats"));
    stale.put("goalWarning",new JSONObject().put("five",five));
    JSONObject fail=ScorePlanRiskEngine.analyze(stale,p,now);
    check(!"hit-pressure".equals(fail.optString("kind")),"old stats never prove recent pressure");
    System.out.println("PASS: two/three pick score risks, quiet 0-0, current target under pressure, stale stats, 42 cutoff");
  }
}
