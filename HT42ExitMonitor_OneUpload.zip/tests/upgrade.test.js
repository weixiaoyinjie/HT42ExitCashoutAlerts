const fs=require('fs'),assert=require('assert'),crypto=require('crypto'),vm=require('vm');
const base='app/src/main/';const read=f=>fs.readFileSync(base+f);
for(const [file,sha] of [
  ['assets/import_parser.js','6328c562c1e411ade805f996faa8cdb825ae2f28e9e74a8e216d4fc01d187933'],
  ['java/com/htlive/monitor/ApiClient.java','999a2ef6d78c81e73bc0b261adab7b71d0860a3cf77a53343144c437406ba41b']
])assert.strictEqual(crypto.createHash('sha256').update(read(file)).digest('hex'),sha,`${file} remains original`);
const html=read('assets/index.html').toString();
assert(html.includes('id="upload"')&&html.includes('id="aiKey"'));
assert(html.includes('id="watchList"')&&html.includes('data-plan-count')&&html.includes('data-plan-field'));
assert(html.includes('两张单（默认）')&&html.includes('三张单'));
for(const tag of ['tab-alerts','tab-settings','tab-monitor','tab-bet'])assert(html.includes(tag));
for(const script of html.matchAll(/<script(?: [^>]*)?>([\s\S]*?)<\/script>/g))new vm.Script(script[1]);
const cfg=fs.readFileSync('app/build.gradle','utf8');
assert(cfg.includes("applicationId 'com.htlive.monitor.exit42'"),'install alongside prior four-point app');
assert(!cfg.includes("applicationId 'com.htlive.monitor.checkpoints'"));
console.log('PASS: screenshot parser and football API client untouched; interface extends original monitor');
